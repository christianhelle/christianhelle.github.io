﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Windows.Phone.System.UserProfile;
using Windows.System;

namespace LockScreenSample
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void DisplayNotificationClicked(object sender, RoutedEventArgs e)
        {
            var tile = ShellTile.ActiveTiles.First();
            var data = new FlipTileData
                           {
                               Count = 1,
                               Title = "Lock Screen Demo"
                           };
            tile.Update(data);
        }

        private void ClearNotificationClicked(object sender, RoutedEventArgs e)
        {
            var tile = ShellTile.ActiveTiles.First();
            var data = new FlipTileData
                           {
                               Count = 0,
                               Title = "Lock Screen Demo"
                           };
            tile.Update(data);
        }

        private async void GoToLockSettingsClicked(object sender, RoutedEventArgs e)
        {
            await Launcher.LaunchUriAsync(new Uri("ms-settings-lock:"));
        }

        private async void SetBackgroundClicked(object sender, RoutedEventArgs e)
        {
            if (await LockScreenManager.RequestAccessAsync() == LockScreenRequestResult.Granted)
            {
                var uri = new Uri("ms-appx:///Assets/LockScreenImage.png", UriKind.Absolute);
                LockScreen.SetImageUri(uri);
            }
            else
            {
                MessageBox.Show("You said no, so I can't update your background.");
            }
        }
    }
}