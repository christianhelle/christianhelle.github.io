﻿using System.Drawing;
using System.Windows.Forms;

namespace OwnerDrawnListSample
{
    class CustomListViewItem
    {
        public string LineOne { get; set; }
        public string LineTwo { get; set; }
    }

    class CustomListView : OwnerDrawnListBase<CustomListViewItem>
    {
        const int topleft = 3;

        StringFormat noWrap;
        Pen pen;
        SolidBrush backgroundBrush;
        SolidBrush selectedBrush;
        SolidBrush selectedTextBrush;
        SolidBrush textBrush;
        Font headerFont;

        public override Font Font
        {
            get { return base.Font; }
            set
            {
                base.Font = value;
                Dispose(headerFont);
                headerFont = new Font(value.Name, value.Size, FontStyle.Bold);
            }
        }

        public CustomListView()
        {
            pen = new Pen(ForeColor);
            textBrush = new SolidBrush(ForeColor);
            backgroundBrush = new SolidBrush(BackColor);
            selectedTextBrush = new SolidBrush(SystemColors.HighlightText);
            selectedBrush = new SolidBrush(SystemColors.Highlight);
            noWrap = new StringFormat(StringFormatFlags.NoWrap);
            headerFont = new Font(base.Font.Name, base.Font.Size, FontStyle.Bold);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            using (var gfx = Graphics.FromImage(OffScreen))
            {
                gfx.FillRectangle(backgroundBrush, 1, 1, Width - 2, Height - 2);

                int top = 1;
                bool lastItem = false;
                bool itemSelected = false; ;

                for (var i = ScrollPosition; i < ScrollPosition + DrawCount; i++)
                {
                    if (top > 1)
                        lastItem = Height - 1 < top;

                    // Fill the rectangle if the item is selected
                    itemSelected = i == SelectedIndex;
                    if (itemSelected)
                    {
                        if (!lastItem)
                        {
                            gfx.FillRectangle(
                                selectedBrush,
                                1,
                                (i == ScrollPosition) ? top : top + 1,
                                ClientSize.Width - (ScrollBarVisible ? ScrollBarWidth : 2),
                                (i == ScrollPosition) ? ItemHeight : ItemHeight - 1);
                        }
                        else
                        {
                            gfx.FillRectangle(
                                selectedBrush,
                                1,
                                top + 1,
                                ClientSize.Width - (ScrollBarVisible ? ScrollBarWidth : 1),
                                ItemHeight);
                        }
                    }

                    // Draw seperator lines after each item unless the item is the last item in the list
                    if (!lastItem)
                    {
                        gfx.DrawLine(
                            pen,
                            1,
                            top + ItemHeight,
                            ClientSize.Width - (ScrollBarVisible ? ScrollBarWidth : 2),
                            top + ItemHeight);
                    }

                    // Get the dimensions for creating the drawing areas
                    var item = Items[i];
                    var size = gfx.MeasureString(item.LineOne, Font);
                    var rectheight = ItemHeight - (int)size.Height - 6;
                    var rectwidth = ClientSize.Width - (ScrollBarVisible ? ScrollBarWidth : 5);

                    // Draw line one with an offset of 3 pixels from the top of the rectangle 
                    // using a bold font (no text wrapping)
                    gfx.DrawString(
                        item.LineOne,
                        headerFont,
                        (i == SelectedIndex) ? selectedTextBrush : textBrush,
                        new RectangleF(topleft, top + 3, rectwidth, rectheight),
                        noWrap);

                    // Draw line two with an offset of 3 pixels from the bottom of line one 
                    // (no text wrapping)
                    gfx.DrawString(
                        item.LineTwo,
                        Font,
                        (i == SelectedIndex) ? selectedTextBrush : textBrush,
                        new RectangleF(topleft, top + size.Height + 6, rectwidth, rectheight),
                        noWrap);

                    // Set the top for the next item
                    top += ItemHeight;
                }

                e.Graphics.DrawImage(OffScreen, 0, 0);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Dispose(headerFont);
                Dispose(backgroundBrush);
                Dispose(textBrush);
                Dispose(selectedTextBrush);
                Dispose(selectedBrush);
                Dispose(pen);
            }

            base.Dispose(disposing);
        }
    }
}
