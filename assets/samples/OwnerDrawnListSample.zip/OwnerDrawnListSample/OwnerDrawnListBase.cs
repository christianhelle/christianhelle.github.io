﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OwnerDrawnListSample
{
    abstract class OwnerDrawnListBase<T> : Control where T : class
    {
        int selectedIndex;
        int visibleItemsPortrait;
        int visibleItemsLandscape;
        VScrollBar scrollBar;

        protected OwnerDrawnListBase()
            : this(7, 4)
        {
        }

        protected OwnerDrawnListBase(int visibleItemsPortrait, int visibleItemsLandscape)
        {
            this.visibleItemsPortrait = visibleItemsPortrait;
            this.visibleItemsLandscape = visibleItemsLandscape;

            Items = new List<T>();

            scrollBar = new VScrollBar { Parent = this, Visible = false, SmallChange = 1 };
            scrollBar.ValueChanged += (sender, e) => Invalidate();
        }

        public List<T> Items { get; private set; }

        public int SelectedIndex
        {
            get { return selectedIndex; }
            set
            {
                selectedIndex = value;
                if (SelectedIndexChanged != null)
                    SelectedIndexChanged(this, EventArgs.Empty);
                Invalidate();
            }
        }

        public event EventHandler SelectedIndexChanged;

        protected virtual void OnSelectedIndexChanged(EventArgs e)
        {
            if (SelectedIndexChanged != null)
                SelectedIndexChanged(this, e);
        }

        public T SelectedItem
        {
            get
            {
                if (selectedIndex >= 0 && selectedIndex < Items.Count)
                    return Items[selectedIndex];
                else
                    return null;
            }
        }

        protected Bitmap OffScreen { get; private set; }

        protected int VisibleItems
        {
            get
            {
                if (Screen.PrimaryScreen.Bounds.Height > Screen.PrimaryScreen.Bounds.Width)
                    return visibleItemsPortrait;
                else
                    return visibleItemsLandscape;
            }
        }

        protected int ItemHeight
        {
            get { return Height / VisibleItems; }
        }

        protected int ScrollPosition
        {
            get { return scrollBar.Value; }
        }

        protected bool ScrollBarVisible
        {
            get { return scrollBar.Visible; }
        }

        protected int ScrollBarWidth
        {
            get { return scrollBar.Width; }
        }

        protected int DrawCount
        {
            get
            {
                if (ScrollPosition + scrollBar.LargeChange > scrollBar.Maximum)
                    return scrollBar.Maximum - ScrollPosition + 1;
                else
                    return scrollBar.LargeChange;
            }
        }

        #region Overrides

        protected override void OnResize(EventArgs e)
        {
            scrollBar.Bounds = new Rectangle(
                ClientSize.Width - scrollBar.Width,
                0,
                scrollBar.Width,
                ClientSize.Height);

            Dispose(OffScreen);

            if (Items.Count > VisibleItems)
            {
                scrollBar.Visible = true;
                scrollBar.LargeChange = VisibleItems;
                OffScreen = new Bitmap(ClientSize.Width - scrollBar.Width, ClientSize.Height);
            }
            else
            {
                scrollBar.Visible = false;
                scrollBar.LargeChange = Items.Count;
                OffScreen = new Bitmap(ClientSize.Width, ClientSize.Height);
            }
            DrawBorder();

            scrollBar.Maximum = Items.Count - 1;
        }

        private void DrawBorder()
        {
            using (var gfx = Graphics.FromImage(OffScreen))
            using (var pen = new Pen(SystemColors.ControlText))
                gfx.DrawRectangle(pen, new Rectangle(0, 0, OffScreen.Width - 1, OffScreen.Height - 1));
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            // Update the selected index based on where the user clicks
            SelectedIndex = scrollBar.Value + (e.Y / ItemHeight);
            if (SelectedIndex > Items.Count - 1)
                SelectedIndex = -1;

            if (!Focused)
                Focus();

            base.OnMouseUp(e);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // To avoid flickering, do all drawing in OnPaint
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
                Dispose(OffScreen);
            base.Dispose(disposing);
        }

        #endregion

        protected static void Dispose(IDisposable obj)
        {
            if (obj != null)
            {
                obj.Dispose();
                obj = null;
            }
        }
    }
}
