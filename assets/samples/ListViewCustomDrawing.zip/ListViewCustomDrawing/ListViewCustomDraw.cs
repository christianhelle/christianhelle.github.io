﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;
using System.Globalization;

namespace ListViewCustomDrawing
{   
    class ListViewCustomDraw : ListViewEx
    {
        [DllImport("coredll.dll")]
        static extern IntPtr CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("coredll")]
        static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, ref RECT lParam);

        [DllImport("coredll.dll")]
        static extern uint SendMessage(IntPtr hwnd, uint msg, uint wparam, uint lparam);

        [DllImport("coredll.dll", SetLastError = true)]
        static extern int SetWindowLong(IntPtr hWnd, int nIndex, WndProcDelegate newProc);

        [DllImport("coredll.dll", SetLastError = true)]
        static extern IntPtr GetWindowLong(IntPtr hWnd, int nIndex);

        const int GWL_WNDPROC = -4;

        const int WM_NOTIFY = 0x4E;
        const int NM_CUSTOMDRAW = (-12);

        const int CDRF_NOTIFYITEMDRAW = 0x00000020;
        const int CDRF_NOTIFYSUBITEMDRAW = CDRF_NOTIFYITEMDRAW;
        const int CDRF_NOTIFYPOSTPAINT = 0x00000010;
        const int CDRF_SKIPDEFAULT = 0x00000004;
        const int CDRF_DODEFAULT = 0x00000000;
        const int CDDS_PREPAINT = 0x00000001;
        const int CDDS_POSTPAINT = 0x00000002;
        const int CDDS_ITEM = 0x00010000;
        const int CDDS_ITEMPREPAINT = (CDDS_ITEM | CDDS_PREPAINT);
        const int CDDS_SUBITEM = 0x00020000;
        const int CDIS_SELECTED = 0x0001;
        const int LVM_GETSUBITEMRECT = (0x1000 + 56);

        delegate IntPtr WndProcDelegate(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
        IntPtr lpPrevWndFunc;

        public ListViewCustomDraw()
        {
            View = View.Details;
            DoubleBuffering = true;
            GridLines = true;
            Gradient = true;

            ParentChanged += delegate
            {
                lpPrevWndFunc = GetWindowLong(Parent.Handle, GWL_WNDPROC);
                SetWindowLong(Parent.Handle, GWL_WNDPROC, WndProc);
            };
        }

        private IntPtr WndProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam)
        {
            if (msg == WM_NOTIFY)
            {
                var nmhdr = (NMHDR)Marshal.PtrToStructure(lParam, typeof(NMHDR));
                if (nmhdr.hwndFrom == Handle && nmhdr.code == NM_CUSTOMDRAW)
                    return CustomDraw(hWnd, msg, wParam, lParam);

            }

            return CallWindowProc(lpPrevWndFunc, hWnd, msg, wParam, lParam);
        }

        private IntPtr CustomDraw(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam)
        {
            int result;
            var nmlvcd = (NMLVCUSTOMDRAW)Marshal.PtrToStructure(lParam, typeof(NMLVCUSTOMDRAW));
            switch (nmlvcd.nmcd.dwDrawStage)
            {
                case CDDS_PREPAINT:
                    result = CDRF_NOTIFYITEMDRAW;
                    break;

                case CDDS_ITEMPREPAINT:
                    var itemBounds = nmlvcd.nmcd.rc.ToRectangle();
                    if ((nmlvcd.nmcd.uItemState & CDIS_SELECTED) != 0)
                    {
                        using (var brush = new SolidBrush(SystemColors.Highlight))
                        using (var graphics = Graphics.FromHdc(nmlvcd.nmcd.hdc))
                            graphics.FillRectangle(brush, itemBounds);
                    }

                    result = CDRF_NOTIFYSUBITEMDRAW;
                    break;

                case CDDS_SUBITEM | CDDS_ITEMPREPAINT:
                    var index = nmlvcd.nmcd.dwItemSpec;
                    var rect = new RECT();
                    rect.top = nmlvcd.iSubItem;
                    SendMessage(Handle, LVM_GETSUBITEMRECT, index, ref rect);
                    rect.left += 2;

                    Color textColor;
                    if ((nmlvcd.nmcd.uItemState & CDIS_SELECTED) != 0)
                        textColor = SystemColors.HighlightText;
                    else
                        textColor = SystemColors.ControlText;

                    using (var brush = new SolidBrush(textColor))
                    using (var graphics = Graphics.FromHdc(nmlvcd.nmcd.hdc))
                        graphics.DrawString(Items[index].SubItems[nmlvcd.iSubItem].Text,
                                            Font,
                                            brush,
                                            rect.ToRectangleF());

                    result = CDRF_SKIPDEFAULT | CDRF_NOTIFYSUBITEMDRAW;
                    break;

                default:
                    result = CDRF_DODEFAULT;
                    break;
            }

            return (IntPtr)result;
        }
    }
}
