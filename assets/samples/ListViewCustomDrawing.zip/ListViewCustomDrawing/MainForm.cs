﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ListViewCustomDrawing
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            listViewCustomDraw1.BeginUpdate();

            listViewCustomDraw1.Columns.Add(new ColumnHeader { Text = "Col 1", Width = 75 });
            listViewCustomDraw1.Columns.Add(new ColumnHeader { Text = "Col 2", Width = 75 });
            listViewCustomDraw1.Columns.Add(new ColumnHeader { Text = "Col 3", Width = 75 });

            for (int i = 0; i < 10; i++)
                listViewCustomDraw1.Items.Add(
                    new ListViewItem(
                        new[] 
                        { 
                            "Hello", "World", i.ToString() 
                        }));

            listViewCustomDraw1.EndUpdate();
        }
    }
}