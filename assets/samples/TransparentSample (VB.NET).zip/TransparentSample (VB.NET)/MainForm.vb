Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms

Namespace TransparentSample
    Partial Public Class MainForm
        Inherits FormBase
        Public Sub New()
            InitializeComponent()
        End Sub


    End Class
End Namespace
