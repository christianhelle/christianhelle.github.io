Namespace TransparentSample
    Partial Class MainForm
        ''' <summary> 
        ''' Required designer variable. 
        ''' </summary> 
        Private components As System.ComponentModel.IContainer = Nothing
        Private mainMenu1 As System.Windows.Forms.MainMenu

        ''' <summary> 
        ''' Clean up any resources being used. 
        ''' </summary> 
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param> 
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary> 
        ''' Required method for Designer support - do not modify 
        ''' the contents of this method with the code editor. 
        ''' </summary> 
        Private Sub InitializeComponent()
            Dim resources As New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
            Me.mainMenu1 = New System.Windows.Forms.MainMenu()
            Me.menuItem1 = New System.Windows.Forms.MenuItem()
            Me.transparentLabel1 = New TransparentSample.TransparentLabel()
            Me.transparentLabel2 = New TransparentSample.TransparentLabel()
            Me.transparentLabel3 = New TransparentSample.TransparentLabel()
            Me.transparentLabel4 = New TransparentSample.TransparentLabel()
            Me.transparentLabel5 = New TransparentSample.TransparentLabel()
            Me.SuspendLayout()
            ' 
            ' transparentLabel1 
            ' 
            Me.transparentLabel1.Font = New System.Drawing.Font("Tahoma", 12.0F, System.Drawing.FontStyle.Bold)
            Me.transparentLabel1.ForeColor = System.Drawing.Color.DarkBlue
            Me.transparentLabel1.Location = New System.Drawing.Point(33, 13)
            Me.transparentLabel1.Name = "transparentLabel1"
            Me.transparentLabel1.Size = New System.Drawing.Size(175, 22)
            Me.transparentLabel1.TabIndex = 1
            Me.transparentLabel1.Text = "Transparent Label"
            Me.transparentLabel1.TextAlign = System.Drawing.ContentAlignment.TopLeft
            ' 
            ' transparentLabel2 
            ' 
            Me.transparentLabel2.Font = New System.Drawing.Font("Tahoma", 12.0F, System.Drawing.FontStyle.Bold)
            Me.transparentLabel2.ForeColor = System.Drawing.Color.DarkBlue
            Me.transparentLabel2.Location = New System.Drawing.Point(16, 58)
            Me.transparentLabel2.Name = "transparentLabel2"
            Me.transparentLabel2.Size = New System.Drawing.Size(175, 22)
            Me.transparentLabel2.TabIndex = 2
            Me.transparentLabel2.Text = "Transparent Label"
            Me.transparentLabel2.TextAlign = System.Drawing.ContentAlignment.TopLeft
            ' 
            ' transparentLabel3 
            ' 
            Me.transparentLabel3.Font = New System.Drawing.Font("Tahoma", 12.0F, System.Drawing.FontStyle.Bold)
            Me.transparentLabel3.ForeColor = System.Drawing.Color.DarkBlue
            Me.transparentLabel3.Location = New System.Drawing.Point(33, 97)
            Me.transparentLabel3.Name = "transparentLabel3"
            Me.transparentLabel3.Size = New System.Drawing.Size(175, 22)
            Me.transparentLabel3.TabIndex = 3
            Me.transparentLabel3.Text = "Transparent Label"
            Me.transparentLabel3.TextAlign = System.Drawing.ContentAlignment.TopLeft
            ' 
            ' transparentLabel4 
            ' 
            Me.transparentLabel4.Font = New System.Drawing.Font("Tahoma", 12.0F, System.Drawing.FontStyle.Bold)
            Me.transparentLabel4.ForeColor = System.Drawing.Color.DarkBlue
            Me.transparentLabel4.Location = New System.Drawing.Point(16, 143)
            Me.transparentLabel4.Name = "transparentLabel4"
            Me.transparentLabel4.Size = New System.Drawing.Size(175, 22)
            Me.transparentLabel4.TabIndex = 4
            Me.transparentLabel4.Text = "Transparent Label"
            Me.transparentLabel4.TextAlign = System.Drawing.ContentAlignment.TopLeft
            ' 
            ' transparentLabel5 
            ' 
            Me.transparentLabel5.Font = New System.Drawing.Font("Tahoma", 12.0F, System.Drawing.FontStyle.Bold)
            Me.transparentLabel5.ForeColor = System.Drawing.Color.DarkBlue
            Me.transparentLabel5.Location = New System.Drawing.Point(42, 182)
            Me.transparentLabel5.Name = "transparentLabel5"
            Me.transparentLabel5.Size = New System.Drawing.Size(175, 22)
            Me.transparentLabel5.TabIndex = 5
            Me.transparentLabel5.Text = "Transparent Label"
            Me.transparentLabel5.TextAlign = System.Drawing.ContentAlignment.TopLeft
            ' 
            ' MainForm 
            ' 
            Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0F, 96.0F)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
            Me.AutoScroll = True
            Me.ClientSize = New System.Drawing.Size(240, 268)
            Me.Controls.Add(Me.transparentLabel5)
            Me.Controls.Add(Me.transparentLabel4)
            Me.Controls.Add(Me.transparentLabel3)
            Me.Controls.Add(Me.transparentLabel2)
            Me.Controls.Add(Me.transparentLabel1)
            Me.Menu = Me.mainMenu1
            Me.Name = "MainForm"
            Me.Text = "MainForm"
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private menuItem1 As System.Windows.Forms.MenuItem
        Private transparentLabel1 As TransparentLabel
        Private transparentLabel2 As TransparentLabel
        Private transparentLabel3 As TransparentLabel
        Private transparentLabel4 As TransparentLabel
        Private transparentLabel5 As TransparentLabel
    End Class
End Namespace