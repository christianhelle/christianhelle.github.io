Imports System
Imports System.Windows.Forms
Imports System.Drawing

Namespace TransparentSample
    Public Class TransparentControlBase
        Inherits Control
        Protected HasBackground As Boolean = False

        Protected Overloads Overrides Sub OnPaintBackground(ByVal e As PaintEventArgs)
            Dim form As IControlBackground = TryCast(Parent, IControlBackground)
            If form Is Nothing Then
                MyBase.OnPaintBackground(e)
                Return
            Else
                HasBackground = True
            End If

            e.Graphics.DrawImage(form.BackgroundImage, 0, 0, Bounds, GraphicsUnit.Pixel)
        End Sub

        Protected Overloads Overrides Sub OnTextChanged(ByVal e As EventArgs)
            MyBase.OnTextChanged(e)
            Invalidate()
        End Sub

        Protected Overloads Overrides Sub OnParentChanged(ByVal e As EventArgs)
            MyBase.OnParentChanged(e)
            Invalidate()
        End Sub
    End Class
End Namespace