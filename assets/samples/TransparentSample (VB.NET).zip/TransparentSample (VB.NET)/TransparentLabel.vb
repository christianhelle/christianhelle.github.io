Imports System
Imports System.Drawing
Imports System.Windows.Forms

Namespace TransparentSample
    Public Class TransparentLabel
        Inherits TransparentControlBase
        Private alignment As ContentAlignment = ContentAlignment.TopLeft
        Private format As StringFormat = Nothing
        Private off_screen As Bitmap = Nothing

        Public Sub New()
            format = New StringFormat()
        End Sub

        Public Property TextAlign() As ContentAlignment
            Get
                Return alignment
            End Get
            Set(ByVal value As ContentAlignment)
                alignment = value
                Select Case alignment
                    Case ContentAlignment.TopCenter
                        format.Alignment = StringAlignment.Center
                        format.LineAlignment = StringAlignment.Center
                        Exit Select
                    Case ContentAlignment.TopLeft
                        format.Alignment = StringAlignment.Near
                        format.LineAlignment = StringAlignment.Near
                        Exit Select
                    Case ContentAlignment.TopRight
                        format.Alignment = StringAlignment.Far
                        format.LineAlignment = StringAlignment.Far
                        Exit Select
                End Select
            End Set
        End Property

        Protected Overloads Overrides Sub OnPaint(ByVal e As PaintEventArgs)
            If Not MyBase.HasBackground Then
                If off_screen Is Nothing Then
                    off_screen = New Bitmap(ClientSize.Width, ClientSize.Height)
                End If
                Using g As Graphics = Graphics.FromImage(off_screen)
                    Using brush As New SolidBrush(Parent.BackColor)
                        g.Clear(BackColor)
                        g.FillRectangle(brush, ClientRectangle)
                    End Using
                End Using
            Else
                Using brush As New SolidBrush(ForeColor)
                    e.Graphics.DrawString(Text, Font, brush, New Rectangle(0, 0, Width, Height), format)
                End Using
            End If
        End Sub
    End Class
End Namespace