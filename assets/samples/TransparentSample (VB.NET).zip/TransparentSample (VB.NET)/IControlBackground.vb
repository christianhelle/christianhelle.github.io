Imports System.Drawing

'Namespace TransparentSample
Public Interface IControlBackground
    ReadOnly Property BackgroundImage() As Image
End Interface
'End Namespace