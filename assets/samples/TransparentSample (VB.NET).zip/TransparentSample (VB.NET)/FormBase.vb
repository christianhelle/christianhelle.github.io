Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Reflection

Namespace TransparentSample
    Public Class FormBase
        Inherits Form
        Implements IControlBackground
        Private background As Bitmap
        Public Sub New()
            background = New Bitmap(Assembly.GetExecutingAssembly().GetManifestResourceStream("background.jpg"))
        End Sub

        Protected Overloads Overrides Sub OnPaint(ByVal e As PaintEventArgs)
            e.Graphics.DrawImage(background, 0, 0)
        End Sub

        Public ReadOnly Property BackgroundImage() As Image
            Get
                Return background
            End Get
        End Property

        Public ReadOnly Property BackgroundImage1() As System.Drawing.Image Implements IControlBackground.BackgroundImage
            Get
                Return background
            End Get
        End Property
    End Class
End Namespace