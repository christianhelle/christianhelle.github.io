﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace SemiTransparentSample
{
    class AlphaButton : Control
    {
        private bool pushed;

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            pushed = true;
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            pushed = false;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            using (var backdrop = new Bitmap(Width, Height))
            {
                using (var gxOff = Graphics.FromImage(backdrop))
                {
                    var topRect = new Rectangle(0, 0, ClientSize.Width, ClientSize.Height / 2);
                    var bottomRect = new Rectangle(0, topRect.Height, ClientSize.Width, ClientSize.Height / 2);

                    if (!pushed)
                    {
                        gxOff.GradientFill(
                            bottomRect,
                            Color.FromArgb(0, 0, 11),
                            Color.FromArgb(32, 32, 32),
                            GraphicsExtension.GradientFillDirection.Vertical);

                        gxOff.GradientFill(
                            topRect,
                            Color.FromArgb(176, 176, 176),
                            Color.FromArgb(32, 32, 32),
                            GraphicsExtension.GradientFillDirection.Vertical);
                    }
                    else
                    {
                        gxOff.GradientFill(
                            topRect,
                            Color.FromArgb(0, 0, 11),
                            Color.FromArgb(32, 32, 32),
                            GraphicsExtension.GradientFillDirection.Vertical);

                        gxOff.GradientFill(
                            bottomRect,
                            Color.FromArgb(176, 176, 176),
                            Color.FromArgb(32, 32, 32),
                            GraphicsExtension.GradientFillDirection.Vertical);
                    }

                    using (var border = new Pen(Color.White))
                        gxOff.DrawRectangle(border, 0, 0, ClientSize.Width - 1, ClientSize.Height - 1);

                    if (!string.IsNullOrEmpty(Text))
                    {
                        var size = gxOff.MeasureString(Text, Font);
                        using (var text = new SolidBrush(Color.White))
                            gxOff.DrawString(
                                Text,
                                Font,
                                text,
                                (ClientSize.Width - size.Width) / 2,
                                (ClientSize.Height - size.Height) / 2);
                    }

                    try
                    {
                        var bgOwner = Parent as IControlBackground;
                        if (bgOwner != null && bgOwner.BackgroundImage != null)
                            gxOff.AlphaBlend(bgOwner.BackgroundImage, 70, Location);
                    }
                    catch (MissingMethodException ex)
                    {
                        throw new PlatformNotSupportedException(
                            "AlphaBlend is not a supported GDI feature on this device",
                            ex);
                    }
                }

                e.Graphics.DrawImage(backdrop, 0, 0);
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
        }
    }
}
