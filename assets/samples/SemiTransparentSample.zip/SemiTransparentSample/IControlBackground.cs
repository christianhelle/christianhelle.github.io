﻿using System.Drawing;

namespace SemiTransparentSample
{
    interface IControlBackground
    {
        Image BackgroundImage { get; }
    }
}
