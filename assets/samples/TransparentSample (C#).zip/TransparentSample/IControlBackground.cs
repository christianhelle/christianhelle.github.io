﻿using System.Drawing;

namespace TransparentSample
{
	public interface IControlBackground
	{
		Image BackgroundImage { get; }
	}
}
