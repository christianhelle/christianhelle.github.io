﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TransparentSample
{
	static class Program
	{		
		[MTAThread]
		static void Main()
		{
			Application.Run(new MainForm());
		}
	}
}