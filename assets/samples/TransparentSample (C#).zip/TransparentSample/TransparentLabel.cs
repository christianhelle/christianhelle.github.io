﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace TransparentSample
{
	public class TransparentLabel : TransparentControlBase
	{
		ContentAlignment alignment = ContentAlignment.TopLeft;
		StringFormat format = null;
		Bitmap off_screen = null;

		public TransparentLabel()
		{
			format = new StringFormat();
		}

		public ContentAlignment TextAlign
		{
			get { return alignment; }
			set
			{
				alignment = value;
				switch (alignment) {
					case ContentAlignment.TopCenter:
						format.Alignment = StringAlignment.Center;
						format.LineAlignment = StringAlignment.Center;
						break;
					case ContentAlignment.TopLeft:
						format.Alignment = StringAlignment.Near;
						format.LineAlignment = StringAlignment.Near;
						break;
					case ContentAlignment.TopRight:
						format.Alignment = StringAlignment.Far;
						format.LineAlignment = StringAlignment.Far;
						break;
				}
			}
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			if (!base.HasBackground) {
				if (off_screen == null) {
					off_screen = new Bitmap(ClientSize.Width, ClientSize.Height);
				}
				using (Graphics g = Graphics.FromImage(off_screen)) {
					using (SolidBrush brush = new SolidBrush(Parent.BackColor)) {
						g.Clear(BackColor);
						g.FillRectangle(brush, ClientRectangle);
					}
				}
			} else {
				using (SolidBrush brush = new SolidBrush(ForeColor)) {
					e.Graphics.DrawString(
						Text,
						Font,
						brush,
						new Rectangle(0, 0, Width, Height),
						format);
				}
			}
		}
	}
}
