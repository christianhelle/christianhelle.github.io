﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace TransparentSample
{
	public class TransparentControlBase : Control
	{
		protected bool HasBackground = false;

		protected override void OnPaintBackground(PaintEventArgs e)
		{
			IControlBackground form = Parent as IControlBackground;
			if (form == null) {
				base.OnPaintBackground(e);
				return;
			} else {
				HasBackground = true;
			}

			e.Graphics.DrawImage(
				form.BackgroundImage,
				0,
				0,
				Bounds,
				GraphicsUnit.Pixel);
		}

		protected override void OnTextChanged(EventArgs e)
		{
			base.OnTextChanged(e);
			Invalidate();
		}

		protected override void OnParentChanged(EventArgs e)
		{
			base.OnParentChanged(e);
			Invalidate();
		}
	}
}
