﻿namespace TransparentSample
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu1;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.transparentLabel1 = new TransparentSample.TransparentLabel();
			this.transparentLabel2 = new TransparentSample.TransparentLabel();
			this.transparentLabel3 = new TransparentSample.TransparentLabel();
			this.transparentLabel4 = new TransparentSample.TransparentLabel();
			this.transparentLabel5 = new TransparentSample.TransparentLabel();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.Add(this.menuItem1);
			// 
			// menuItem1
			// 
			this.menuItem1.Text = "Exit";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// transparentLabel1
			// 
			this.transparentLabel1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
			this.transparentLabel1.ForeColor = System.Drawing.Color.DarkBlue;
			this.transparentLabel1.Location = new System.Drawing.Point(33, 13);
			this.transparentLabel1.Name = "transparentLabel1";
			this.transparentLabel1.Size = new System.Drawing.Size(175, 22);
			this.transparentLabel1.TabIndex = 1;
			this.transparentLabel1.Text = "Transparent Label";
			this.transparentLabel1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// transparentLabel2
			// 
			this.transparentLabel2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
			this.transparentLabel2.ForeColor = System.Drawing.Color.DarkBlue;
			this.transparentLabel2.Location = new System.Drawing.Point(16, 58);
			this.transparentLabel2.Name = "transparentLabel2";
			this.transparentLabel2.Size = new System.Drawing.Size(175, 22);
			this.transparentLabel2.TabIndex = 2;
			this.transparentLabel2.Text = "Transparent Label";
			this.transparentLabel2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// transparentLabel3
			// 
			this.transparentLabel3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
			this.transparentLabel3.ForeColor = System.Drawing.Color.DarkBlue;
			this.transparentLabel3.Location = new System.Drawing.Point(33, 97);
			this.transparentLabel3.Name = "transparentLabel3";
			this.transparentLabel3.Size = new System.Drawing.Size(175, 22);
			this.transparentLabel3.TabIndex = 3;
			this.transparentLabel3.Text = "Transparent Label";
			this.transparentLabel3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// transparentLabel4
			// 
			this.transparentLabel4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
			this.transparentLabel4.ForeColor = System.Drawing.Color.DarkBlue;
			this.transparentLabel4.Location = new System.Drawing.Point(16, 143);
			this.transparentLabel4.Name = "transparentLabel4";
			this.transparentLabel4.Size = new System.Drawing.Size(175, 22);
			this.transparentLabel4.TabIndex = 4;
			this.transparentLabel4.Text = "Transparent Label";
			this.transparentLabel4.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// transparentLabel5
			// 
			this.transparentLabel5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
			this.transparentLabel5.ForeColor = System.Drawing.Color.DarkBlue;
			this.transparentLabel5.Location = new System.Drawing.Point(42, 182);
			this.transparentLabel5.Name = "transparentLabel5";
			this.transparentLabel5.Size = new System.Drawing.Size(175, 22);
			this.transparentLabel5.TabIndex = 5;
			this.transparentLabel5.Text = "Transparent Label";
			this.transparentLabel5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(240, 268);
			this.Controls.Add(this.transparentLabel5);
			this.Controls.Add(this.transparentLabel4);
			this.Controls.Add(this.transparentLabel3);
			this.Controls.Add(this.transparentLabel2);
			this.Controls.Add(this.transparentLabel1);
			this.Menu = this.mainMenu1;
			this.Name = "MainForm";
			this.Text = "MainForm";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.MenuItem menuItem1;
		private TransparentLabel transparentLabel1;
		private TransparentLabel transparentLabel2;
		private TransparentLabel transparentLabel3;
		private TransparentLabel transparentLabel4;
		private TransparentLabel transparentLabel5;
	}
}