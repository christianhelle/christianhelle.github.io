﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;

namespace TransparentSample
{
	public class FormBase : Form, IControlBackground
	{
		Bitmap background;

		public FormBase()
		{
			background = new Bitmap(
				Assembly.GetExecutingAssembly().GetManifestResourceStream(
				"TransparentSample.background.jpg"));
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			e.Graphics.DrawImage(background, 0, 0);
		}

		public Image BackgroundImage
		{
			get { return background; }
		}
	}
}
