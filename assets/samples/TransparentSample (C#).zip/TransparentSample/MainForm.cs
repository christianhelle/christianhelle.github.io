﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TransparentSample
{
	public partial class MainForm : FormBase
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void menuItem1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}
	}
}