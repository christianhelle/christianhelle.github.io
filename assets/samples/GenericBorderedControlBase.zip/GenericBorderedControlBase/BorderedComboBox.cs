﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace BorderedControl
{
    public class BorderedComboBox : BorderedControlBase<ComboBox>
    {
        public BorderedComboBox()
        {
            innerControl.SelectedIndexChanged += delegate { if (SelectedIndexChanged != null) SelectedIndexChanged(this, EventArgs.Empty); };
            innerControl.DataSourceChanged += delegate { if (DataSourceChanged != null) DataSourceChanged(this, EventArgs.Empty); };
            innerControl.DisplayMemberChanged += delegate { if (DisplayMemberChanged != null) DisplayMemberChanged(this, EventArgs.Empty); };
            innerControl.SelectedValueChanged += delegate { if (SelectedValueChanged != null) SelectedValueChanged(this, EventArgs.Empty); };
        }

        public event EventHandler SelectedIndexChanged;
        public event EventHandler DataSourceChanged;
        public event EventHandler DisplayMemberChanged;
        public event EventHandler SelectedValueChanged;

        #region Wrapper Properties
        public ComboBoxStyle DropDownStyle
        {
            get { return innerControl.DropDownStyle; }
            set { innerControl.DropDownStyle = value; }
        }

        public ComboBox.ObjectCollection Items
        {
            get { return innerControl.Items; }
        }

        public int SelectedIndex
        {
            get { return innerControl.SelectedIndex; }
            set { innerControl.SelectedIndex = value; }
        }

        public object SelectedItem
        {
            get { return innerControl.SelectedItem; }
            set { innerControl.SelectedItem = value; }
        }

        public string SelectedText
        {
            get { return innerControl.SelectedText; }
            set { innerControl.SelectedText = value; }
        }

        public int SelectionLength
        {
            get { return innerControl.SelectionLength; }
            set { innerControl.SelectionLength = value; }
        }

        public int SelectionStart
        {
            get { return innerControl.SelectionStart; }
            set { innerControl.SelectionStart = value; }
        }

        public object DataSource
        {
            get { return innerControl.DataSource; }
            set { innerControl.DataSource = value; }
        }

        public string DisplayMember
        {
            get { return innerControl.DisplayMember; }
            set { innerControl.DisplayMember = value; DisplayMemberChanged(this, EventArgs.Empty); }
        }

        public object SelectedValue
        {
            get { return innerControl.SelectedValue; }
            set { innerControl.SelectedValue = value; SelectedValueChanged(this, EventArgs.Empty); }
        }

        public string ValueMember
        {
            get { return innerControl.ValueMember; }
            set { innerControl.ValueMember = value; }
        }
        #endregion

        #region Wrapped Methods
        public void BeginUpdate()
        {
            innerControl.BeginUpdate();
        }

        public void EndUpdate()
        {
            innerControl.EndUpdate();
        }

        public void Select(int start, int length)
        {
            innerControl.Select(start, length);
        }

        public void SelectAll()
        {
            innerControl.SelectAll();
        }

        public string GetItemText(object item)
        {
            return innerControl.GetItemText(item);
        }
        #endregion
    }
}
