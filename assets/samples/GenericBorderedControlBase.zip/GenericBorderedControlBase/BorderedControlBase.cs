﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace BorderedControl
{
    [EditorBrowsable(EditorBrowsableState.Never)]
    public abstract class BorderedControlBase<T> : Control
        where T : Control, new()
    {
        protected T innerControl;

        protected BorderedControlBase()
        {
            innerControl = new T();
            innerControl.GotFocus += delegate { OnGotFocus(EventArgs.Empty); };
            innerControl.LostFocus += delegate { OnLostFocus(EventArgs.Empty); };
            innerControl.TextChanged += delegate { OnTextChanged(EventArgs.Empty); };
            Controls.Add(innerControl);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            innerControl.Bounds = new Rectangle(1, 1, ClientSize.Width - 2, ClientSize.Height - 2);
            Height = innerControl.Height + 2;
        }

        protected override void OnParentChanged(EventArgs e)
        {
            base.OnParentChanged(e);
            Invalidate();
        }

        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Invalidate();
            innerControl.Focus();
        }

        protected override void OnLostFocus(EventArgs e)
        {
            base.OnLostFocus(e);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(innerControl.Focused ? SystemColors.Highlight : BackColor);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            if (Environment.OSVersion.Platform != PlatformID.WinCE)
                base.OnPaint(e);
        }

        public override Font Font
        {
            get { return base.Font; }
            set
            {
                if (Environment.OSVersion.Platform != PlatformID.WinCE)
                {
                    var font = new Font(value.Name, value.Size, value.Style);
                    base.Font = innerControl.Font = font;
                }
                else
                    base.Font = innerControl.Font = value;
            }
        }

        public override string Text
        {
            get { return innerControl.Text; }
            set { innerControl.Text = value; }
        }

        public override bool Focused
        {
            get { return innerControl.Focused; }
        }
    }
}
