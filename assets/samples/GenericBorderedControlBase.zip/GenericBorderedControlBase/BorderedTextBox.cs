﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;

namespace BorderedControl
{
    public class BorderedTextBox : BorderedControlBase<TextBox>
    {
        [DllImport("coredll.dll")]
        static extern bool HideCaret(IntPtr hwnd);

        [DllImport("coredll.dll")]
        static extern bool ShowCaret(IntPtr hwnd);

        public BorderedTextBox()
        {
            innerControl.KeyDown += (sender, e) => OnKeyDown(e);
            innerControl.KeyPress += (sender, e) => OnKeyPress(e);
            innerControl.KeyUp += (sender, e) => OnKeyUp(e);
        }

        public bool EnabledCaret { get; set; }

        #region Wrapped Properties

        public bool AcceptsReturn
        {
            get { return innerControl.AcceptsReturn; }
            set { innerControl.AcceptsReturn = value; }
        }

        public bool AcceptsTab
        {
            get { return innerControl.AcceptsTab; }
            set { innerControl.AcceptsTab = value; }
        }

        public bool CanUndo
        {
            get { return innerControl.CanUndo; }
        }

        public bool HideSelection
        {
            get { return innerControl.HideSelection; }
            set { innerControl.HideSelection = value; }
        }

        public int MaxLength
        {
            get { return innerControl.MaxLength; }
            set { innerControl.MaxLength = value; }
        }

        public bool Modified
        {
            get { return innerControl.Modified; }
            set { innerControl.Modified = value; }
        }

        public bool Multiline
        {
            get { return innerControl.Multiline; }
            set { innerControl.Multiline = value; }
        }

        public char PasswordChar
        {
            get { return innerControl.PasswordChar; }
            set { innerControl.PasswordChar = value; }
        }

        public bool ReadOnly
        {
            get { return innerControl.ReadOnly; }
            set { innerControl.ReadOnly = value; }
        }

        public override Color BackColor
        {
            get { return innerControl.BackColor; }
            set { innerControl.BackColor = value; }
        }

        public ScrollBars ScrollBars
        {
            get { return innerControl.ScrollBars; }
            set { innerControl.ScrollBars = value; }
        }

        public string SelectedText
        {
            get { return innerControl.SelectedText; }
            set { innerControl.SelectedText = value; }
        }

        public int SelectionLength
        {
            get { return innerControl.SelectionLength; }
            set { innerControl.SelectionLength = value; }
        }

        public int SelectionStart
        {
            get { return innerControl.SelectionStart; }
            set { innerControl.SelectionStart = value; }
        }

        public HorizontalAlignment TextAlign
        {
            get { return innerControl.TextAlign; }
            set { innerControl.TextAlign = value; }
        }

        public int TextLength
        {
            get { return innerControl.TextLength; }
        }

        public bool WordWrap
        {
            get { return innerControl.WordWrap; }
            set { innerControl.WordWrap = value; }
        }

        #endregion

        #region Wrapped Methods

        public void ScrollToCaret()
        {
            innerControl.ScrollToCaret();
        }

        public void Select(int start, int length)
        {
            innerControl.Select(start, length);
        }

        public void SelectAll()
        {
            innerControl.SelectAll();
        }

        public void Undo()
        {
            innerControl.Undo();
        }

        #endregion

        #region Overridden Methods
        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);

            if (!EnabledCaret)
                HideCaret(Handle);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            base.OnLostFocus(e);

            if (!EnabledCaret)
                ShowCaret(Handle);
        } 
        #endregion
    }
}
