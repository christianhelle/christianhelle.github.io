using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PuzzleGame
{
    class PuzzlePiece
    {
        public int Index { get; set; }
        public Vector2 Bounds { get; set; }

        public override int GetHashCode()
        {
            return Index.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            var piece = obj as PuzzlePiece;
            if (piece != null)
                return Index.Equals(piece.Index);
            return base.Equals(obj);
        }
    }

    enum DrawMode
    {
        Puzzle,
        Congratulations
    }

    public class PuzzleGame : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D previewTexture;
        Vector2 previewVector, emptyPiece, totalGameTimeVector, congratulationsVector;
        SpriteFont gameTimerFont, congratulationsFont;
        Dictionary<int, Texture2D> puzzlePieces;
        Dictionary<int, PuzzlePiece> scrambledPieces;
        DrawMode Mode;
        int height, width;
        double elapsedTime, playingTime;
        Queue<Keys> pendingCommands;
        const int PIECE_COUNT = 4 * 4;
        bool solved;
        static bool animating;

        public PuzzleGame()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            pendingCommands = new Queue<Keys>();
            Mode = DrawMode.Puzzle;
            previewVector = new Vector2(0, 0);
            totalGameTimeVector = new Vector2(10, 10);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            previewTexture = Content.Load<Texture2D>("PuzzleImage");
            gameTimerFont = Content.Load<SpriteFont>("GameTimeFont");
            congratulationsFont = Content.Load<SpriteFont>("CongratulationsFont");

            var size = congratulationsFont.MeasureString("Congrautulations!");
            congratulationsVector = new Vector2(
                (GraphicsDevice.Viewport.Width - size.X) / 2,
                (GraphicsDevice.Viewport.Height - size.Y) / 2);

            Divide();
            Scramble();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            previewTexture.Dispose();
            foreach (var item in puzzlePieces)
                item.Value.Dispose();

            spriteBatch.Dispose();
        }

        private void Divide()
        {
            int idx = 0;
            int cells = Convert.ToInt32(Math.Sqrt(PIECE_COUNT));
            height = GraphicsDevice.Viewport.Height / cells;
            width = GraphicsDevice.Viewport.Width / cells;
            puzzlePieces = new Dictionary<int, Texture2D>();
            for (int y = 0; y < GraphicsDevice.Viewport.Height; y += height)
            {
                for (int x = 0; x < GraphicsDevice.Viewport.Width; x += width)
                {
                    var rectangle = new Rectangle(x, y, width, height);
                    var data = new Color[width * height];
                    previewTexture.GetData<Color>(0, rectangle, data, 0, data.Length);

                    var piece = new Texture2D(GraphicsDevice, width, height);
                    piece.SetData(data);

                    puzzlePieces.Add(idx++, piece);
                }
            }
        }

        private void Scramble()
        {
            int idx = 0;
            var random = new Random();
            int capacity = puzzlePieces.Count - 1;
            scrambledPieces = new Dictionary<int, PuzzlePiece>(puzzlePieces.Count);

            for (int y = 0; y < GraphicsDevice.Viewport.Height; y += height)
            {
                for (int x = 0; x < GraphicsDevice.Viewport.Width; x += width)
                {
                    if (idx < capacity)
                    {
                        var piece = new PuzzlePiece();
                        while (true)
                        {
                            piece.Index = random.Next(0, capacity);
                            if (!scrambledPieces.ContainsValue(piece))
                                break;
                        }

                        piece.Bounds = new Vector2(x, y);
                        scrambledPieces.Add(idx++, piece);
                    }
                    else
                        emptyPiece = new Vector2(x, y);
                }
            }
            scrambledPieces.Add(idx, new PuzzlePiece { Index = -1 });
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            var mouseState = Mouse.GetState();
            if (mouseState.LeftButton == ButtonState.Pressed)
            {
                if (animating)
                {
                    base.Update(gameTime);
                    return;
                }

                var clickedRectangle = new Rectangle(mouseState.X, mouseState.Y, width, height);
                var pieceRect = new Rectangle(0, 0, width, height);

                for (int i = 0; i < scrambledPieces.Count; i++)
                {
                    pieceRect.X = (int)scrambledPieces[i].Bounds.X;
                    pieceRect.Y = (int)scrambledPieces[i].Bounds.Y;

                    if (!pieceRect.Intersects(clickedRectangle))
                        continue;

                    if (mouseState.X >= emptyPiece.X &&
                        mouseState.X <= emptyPiece.X + width &&
                        mouseState.Y >= emptyPiece.Y &&
                        mouseState.Y <= emptyPiece.Y + height)
                        continue;

                    Keys command = Keys.None;
                    if (pieceRect.X >= emptyPiece.X && pieceRect.X <= emptyPiece.X)
                    {
                        if (pieceRect.Y - height == emptyPiece.Y)
                            command = Keys.Up;
                        else if (pieceRect.Y + height == emptyPiece.Y)
                            command = Keys.Down;
                    }
                    else if (pieceRect.Y >= emptyPiece.Y && pieceRect.Y <= emptyPiece.Y)
                    {
                        if (pieceRect.X - width == emptyPiece.X)
                            command = Keys.Left;
                        else if (pieceRect.X + width == emptyPiece.X)
                            command = Keys.Right;
                    }

                    if (command != Keys.None && !pendingCommands.Contains(command))
                    {
                        pendingCommands.Enqueue(command);
                        Debug.WriteLine("Clicked: " + i);
                    }
                    break;
                }
            }
            else
                elapsedTime += gameTime.ElapsedGameTime.TotalMilliseconds;

            if (elapsedTime >= 10)
            {
                if (pendingCommands.Count > 0)
                    MovePiece(pendingCommands.Dequeue());
                elapsedTime = 0;
            }

            if (!solved)
                playingTime += gameTime.ElapsedGameTime.TotalMilliseconds;

            base.Update(gameTime);
        }

        private void MovePiece(Keys command)
        {
            for (int i = 0; i < scrambledPieces.Count; i++)
            {
                switch (command)
                {
                    case Keys.Up:
                        if (scrambledPieces[i].Bounds.X == emptyPiece.X && scrambledPieces[i].Bounds.Y - height == emptyPiece.Y)
                        {
                            Animate(command, i);
                            return;
                        }
                        break;
                    case Keys.Down:
                        if (scrambledPieces[i].Bounds.X == emptyPiece.X && scrambledPieces[i].Bounds.Y + height == emptyPiece.Y)
                        {
                            Animate(command, i);
                            return;
                        }
                        break;
                    case Keys.Left:
                        if (scrambledPieces[i].Bounds.Y == emptyPiece.Y && scrambledPieces[i].Bounds.X - width == emptyPiece.X)
                        {
                            Animate(command, i);
                            return;
                        }
                        break;
                    case Keys.Right:
                        if (scrambledPieces[i].Bounds.Y == emptyPiece.Y && scrambledPieces[i].Bounds.X + width == emptyPiece.X)
                        {
                            Animate(command, i);
                            return;
                        }
                        break;
                }
            }
        }

        private void Animate(Keys direction, int i)
        {
            animating = true;

            ThreadPool.QueueUserWorkItem((state) =>
            {
                try
                {
                    const int INCREMENT = 2;
                    var newEmptyPiece = scrambledPieces[i].Bounds;

                    while (scrambledPieces[i].Bounds != emptyPiece)
                    {
                        switch (direction)
                        {
                            case Keys.Up:
                                scrambledPieces[i].Bounds = new Vector2(emptyPiece.X, scrambledPieces[i].Bounds.Y - INCREMENT);
                                break;
                            case Keys.Down:
                                scrambledPieces[i].Bounds = new Vector2(emptyPiece.X, scrambledPieces[i].Bounds.Y + INCREMENT);
                                break;
                            case Keys.Left:
                                scrambledPieces[i].Bounds = new Vector2(scrambledPieces[i].Bounds.X - INCREMENT, emptyPiece.Y);
                                break;
                            case Keys.Right:
                                scrambledPieces[i].Bounds = new Vector2(scrambledPieces[i].Bounds.X + INCREMENT, emptyPiece.Y);
                                break;
                        }
                        Thread.Sleep(1);
                    }

                    emptyPiece = newEmptyPiece;
                }
                finally
                {
                    UpdateScrambledIndex(direction, i);
                    CheckForCompletion();
                    animating = false;
                }
            });
        }

        private void UpdateScrambledIndex(Keys command, int index)
        {
            int newIndex = -1;
            int INCREMENT = Convert.ToInt32(Math.Sqrt(PIECE_COUNT));
            switch (command)
            {
                case Keys.Up:
                    newIndex = index - INCREMENT;
                    if (newIndex < 0) newIndex = 0;
                    break;
                case Keys.Down:
                    newIndex = index + INCREMENT;
                    if (newIndex > scrambledPieces.Count - 1) newIndex = scrambledPieces.Count - 1;
                    break;
                case Keys.Left:
                    newIndex = index - 1;
                    if (newIndex < 0) newIndex = 0;
                    break;
                case Keys.Right:
                    newIndex = index + 1;
                    if (newIndex > scrambledPieces.Count - 1) newIndex = scrambledPieces.Count - 1;
                    break;
            }

            var temp = scrambledPieces[newIndex];
            scrambledPieces[newIndex] = scrambledPieces[index];
            scrambledPieces[index] = temp;
        }

        private void CheckForCompletion()
        {
            for (int i = 0; i < scrambledPieces.Count - 1; i++)
                if (scrambledPieces[i].Index != i)
                    return;

            solved = true;
            Mode = DrawMode.Congratulations;
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            spriteBatch.Begin(SpriteSortMode.BackToFront, BlendState.AlphaBlend);

            switch (Mode)
            {
                case DrawMode.Puzzle:
                    spriteBatch.DrawString(gameTimerFont, new TimeSpan(0, 0, 0, 0, (int)playingTime).ToString(), totalGameTimeVector, Color.White);
                    for (int i = 0; i < scrambledPieces.Count; i++)
                    {
                        if (scrambledPieces[i].Index == -1) continue;
                        var piece = puzzlePieces[scrambledPieces[i].Index];
                        spriteBatch.Draw(piece, scrambledPieces[i].Bounds, Color.White);
                    }
                    break;
                case DrawMode.Congratulations:
                    spriteBatch.DrawString(gameTimerFont, new TimeSpan(0, 0, 0, 0, (int)playingTime).ToString(), totalGameTimeVector, Color.White);
                    spriteBatch.DrawString(congratulationsFont, "Congratulations!", congratulationsVector, Color.White);
                    break;
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
