using Atc.Cosmos.EventStore;
using Microsoft.Extensions.Options;

namespace GettingStarted;
