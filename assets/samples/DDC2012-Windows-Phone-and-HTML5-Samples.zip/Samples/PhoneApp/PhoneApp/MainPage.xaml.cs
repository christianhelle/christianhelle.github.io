﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Controls;
using PhoneApp.Interop;

namespace PhoneApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        private readonly Uri mainPage = new Uri("HTML/Default.html", UriKind.Relative);

        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            if (browser.Source != mainPage)
            {
                browser.InvokeScript("eval", "history.back();");
                e.Cancel = true;
            }
            base.OnBackKeyPress(e);
        }

        private void browser_ScriptNotify(object sender, NotifyEventArgs e)
        {
            Debug.WriteLine("Script Notify: " + e.Value);

            try
            {
                var request = JavascriptRequest.Create(e.Value);
                var command = BrowserInteropCommandFactory.Create(request);
                command.Invoke(browser);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            using (var store = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (!store.DirectoryExists("HTML")) store.CreateDirectory("HTML");
                CopyToIsolatedStorage("HTML\\Default.html", store);
                CopyToIsolatedStorage("HTML\\Styles.css", store);
            }
        }

        private static void CopyToIsolatedStorage(string file, IsolatedStorageFile store, bool overwrite = true)
        {
            if (store.FileExists(file) && !overwrite)
                return;

            using (var resourceStream = Application.GetResourceStream(new Uri(file, UriKind.Relative)).Stream)
            using (var fileStream = store.OpenFile(file, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                int bytesRead;
                var buffer = new byte[resourceStream.Length];
                while ((bytesRead = resourceStream.Read(buffer, 0, buffer.Length)) > 0)
                    fileStream.Write(buffer, 0, bytesRead);
            }
        }
    }
}