﻿using System.Collections.Generic;

namespace PhoneApp.Interop
{
    public class JavascriptRequest
    {
        public string MethodName { get; set; }
        public IList<object> Arguments { get; set; }

        public static JavascriptRequest Create(string javascriptArgumentString)
        {
            var parameters = javascriptArgumentString.Split('|');
            var javascriptArgument = new JavascriptRequest { MethodName = parameters[0] };

            if (parameters.Length == 1)
                return javascriptArgument;

            javascriptArgument.Arguments = new List<object>(parameters.Length - 2);
            for (var i = 1; i < parameters.Length; i++)
                javascriptArgument.Arguments.Add(parameters[i]);

            return javascriptArgument;
        }
    }
}
