using Microsoft.Phone.Controls;

namespace PhoneApp.Interop
{
    public abstract class BrowserInteropCommand
    {
        public JavascriptRequest Request { get; private set; }

        protected BrowserInteropCommand(JavascriptRequest javascriptRequest)
        {
            Request = javascriptRequest;
        }

        public abstract void Invoke(WebBrowser browser);
    }
}