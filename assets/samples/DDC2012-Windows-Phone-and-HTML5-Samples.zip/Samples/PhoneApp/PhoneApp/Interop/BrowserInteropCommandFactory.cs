using System;

namespace PhoneApp.Interop
{
    public static class BrowserInteropCommandFactory
    {
        public static BrowserInteropCommand Create(JavascriptRequest request)
        {
            switch (request.MethodName.ToUpperInvariant())
            {
                case "PLAYTRACK":
                    return new PlayTrackCommand(request);
                case "GETMEMORYUSAGE":
                    return new GetMemoryUsageCommand(request);
                case "CAPTUREIMAGE":
                    return new CaptureImageCommand(request);
                case "STARTACCELEROMETER":
                    return new StartAccelerometerCommand(request);

                default:
                    throw new NotImplementedException("The method request by the browser component is not implemented");
            }
        }
    }
}