using System.Linq;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Info;

namespace PhoneApp.Interop
{
    public class GetMemoryUsageCommand : BrowserInteropCommand
    {
        public GetMemoryUsageCommand(JavascriptRequest javascriptRequest)
            : base(javascriptRequest)
        {
        }

        public override void Invoke(WebBrowser browser)
        {
            var response = new object[]
                       {
                           DeviceStatus.ApplicationCurrentMemoryUsage, 
                           DeviceStatus.ApplicationMemoryUsageLimit, 
                           DeviceStatus.ApplicationPeakMemoryUsage,
                           DeviceStatus.DeviceTotalMemory
                       };
            browser.InvokeScript(Request.MethodName + "Callback",
                                 response.Select(c => c.ToString()).ToArray());
        }
    }
}