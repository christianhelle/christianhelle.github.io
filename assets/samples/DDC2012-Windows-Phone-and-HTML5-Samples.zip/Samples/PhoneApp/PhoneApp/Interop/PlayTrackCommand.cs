using System;
using System.Collections.Generic;
using System.IO;
using System.IO.IsolatedStorage;
using System.Runtime.Serialization.Json;
using System.Text;
using Microsoft.Phone.BackgroundAudio;
using Microsoft.Phone.Controls;

namespace PhoneApp.Interop
{
    public class PlayTrackCommand : BrowserInteropCommand
    {
        #region Implementation of IBrowserCommand

        public PlayTrackCommand(JavascriptRequest javascriptRequest)
            : base(javascriptRequest)
        {
        }

        public override void Invoke(WebBrowser browser)
        {
            var data = Encoding.UTF8.GetBytes(Request.Arguments[0].ToString());
            
            // Persist the playlist to isolated storage so the playback agent can perform track skipping
            using (var store = IsolatedStorageFile.GetUserStoreForApplication())
            using (var file = new IsolatedStorageFileStream("playlist.json", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite, store))
                file.Write(data, 0, data.Length);

            // deserialize json data to a clr collection
            IList<Track> tracks;
            using (var stream = new MemoryStream(data))
            {
                var deserializer = new DataContractJsonSerializer(typeof(IList<Track>));
                tracks = (IList<Track>)deserializer.ReadObject(stream);
            }

            // play the first track in the background
            var url = tracks[0].Url;
            var title = tracks[0].Title;
            var artist = tracks[0].Artist;
            var album = tracks[0].Album;
            var track = new AudioTrack(new Uri(url, UriKind.Absolute), title, artist, album, null, null, EnabledPlayerControls.All);
            BackgroundAudioPlayer.Instance.Track = track;
        }

        #endregion
    }

    public class Track
    {
        public string Url { get; set; }
        public string Title { get; set; }
        public string Artist { get; set; }
        public string Album { get; set; }
    }
}