﻿using System;
using System.Windows;
using Microsoft.Devices.Sensors;
using Microsoft.Phone.Controls;

namespace PhoneApp.Interop
{
    public class StartAccelerometerCommand : BrowserInteropCommand
    {
        private static bool isRunning;

        public StartAccelerometerCommand(JavascriptRequest javascriptRequest)
            : base(javascriptRequest)
        {
        }

        public override void Invoke(WebBrowser browser)
        {
            if (isRunning)
                return;

            if (!Accelerometer.IsSupported)
                return;

            var sensor = new Accelerometer { TimeBetweenUpdates = TimeSpan.FromMilliseconds(100) };
            sensor.CurrentValueChanged +=
                (sender, args) => Deployment.Current.Dispatcher.BeginInvoke(
                    () =>
                        {
                            var x = args.SensorReading.Acceleration.X.ToString("0.000");
                            var y = args.SensorReading.Acceleration.Y.ToString("0.000");
                            var z = args.SensorReading.Acceleration.Z.ToString("0.000");

                            browser.InvokeScript("eval", string.Format("accelerometerCallback({0},{1},{2})", x, y, z));
                        });
            sensor.Start();

            isRunning = true;
        }
    }
}