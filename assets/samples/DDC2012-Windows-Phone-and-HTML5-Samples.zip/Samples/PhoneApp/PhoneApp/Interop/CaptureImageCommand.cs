﻿using System.IO;
using System.IO.IsolatedStorage;
using System.Threading;
using System.Windows.Media.Imaging;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;

namespace PhoneApp.Interop
{
    public class CaptureImageCommand : BrowserInteropCommand
    {
        public CaptureImageCommand(JavascriptRequest javascriptRequest)
            : base(javascriptRequest)
        {
        }

        public override void Invoke(WebBrowser browser)
        {
            var photoCameraCapture = new CameraCaptureTask();
            photoCameraCapture.Completed += (sender, result) =>
            {
                if (result.TaskResult != TaskResult.OK)
                    return;
                SaveToIsolatedStorage(result.ChosenPhoto, "HTML\\capture.jpg");
                browser.InvokeScript(Request.MethodName + "Callback", "capture.jpg");
            };
            photoCameraCapture.Show();
        }

        private void SaveToIsolatedStorage(Stream imageStream, string fileName)
        {
            using (var store = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (store.FileExists(fileName))
                    store.DeleteFile(fileName);

                using (var fileStream = store.CreateFile(fileName))
                {
                    var bitmap = new BitmapImage();
                    bitmap.SetSource(imageStream);

                    var wb = new WriteableBitmap(bitmap);
                    wb.SaveJpeg(fileStream, wb.PixelWidth, wb.PixelHeight, 0, 100);
                }
            }
        }
    }
}
