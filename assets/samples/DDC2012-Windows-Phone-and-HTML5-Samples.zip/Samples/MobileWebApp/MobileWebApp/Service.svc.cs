﻿
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

namespace MobileWebApp
{
    [DataContract]
    public class AudioTrack
    {
        [DataMember]
        public string Url { get; set; }
        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public string Artist { get; set; }
        [DataMember]
        public string Album { get; set; }
    }

    [CollectionDataContract]
    public class AudioTracks : List<AudioTrack>
    {
    }

    [ServiceContract]
    public interface IRestService
    {
        [OperationContract]
        [WebGet(RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "json/getplaylist")]
        AudioTracks GetPlaylist();
    }

    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service : IRestService
    {
        public AudioTracks GetPlaylist()
        {
            return new AudioTracks
                       {
                           new AudioTrack
                               {
                                   Url = "http://dl.dropbox.com/u/18352048/Music/Always%20with%20me%20Always%20with%20you.mp3",
                                   Title = "Always with me, always with you (Cover)",
                                   Album = "Some album",
                                   Artist = "Christian R. Helle"
                               },
                           new AudioTrack
                               {
                                   Url = "http://dl.dropbox.com/u/18352048/Music/Blues%20Jam%20on%20a%20Fender%20Tele.mp3",
                                   Title = "Tele Blues",
                                   Album = "Some album",
                                   Artist = "Christian R. Helle"
                               },
                           new AudioTrack
                               {
                                   Url = "http://dl.dropbox.com/u/18352048/Music/Blues%20Jam%20on%20a%20Yamaha%20TRGX.mp3",
                                   Title="TRGX Blues",
                                   Album = "Some album",
                                   Artist = "Christian R. Helle"
                               },
                           new AudioTrack
                               {
                                   Url = "http://dl.dropbox.com/u/18352048/Music/Arghhhh.mp3",
                                   Title = "Arghhh",
                                   Album = "Some album",
                                   Artist = "Christian R. Helle"
                               }
                       };
        }
    }
}
