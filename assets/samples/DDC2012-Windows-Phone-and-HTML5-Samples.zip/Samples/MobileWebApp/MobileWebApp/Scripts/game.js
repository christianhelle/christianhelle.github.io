﻿var _row = 4;
var _col = 2;

$(function () {
    var image = new Image();
    image.src = "Images/david.jpg";
    image.onload = function () {
        for (var row = 0; row < 5; row++) {
            for (var col = 0; col < 3; col++) {
                if (!(row == 4 && col == 2)) {
                    var dc = document.getElementById("c" + row + col).getContext("2d");
                    dc.drawImage(image, col * 160, row * 160, 160, 160, 0, 0, 160, 160);
                }
            }
        }
        $("canvas").click(onClick);
    };
});

function onClick() {
    var piece = $(this);

    // Get the row and column
    var row = piece.position().top / 160;
    var col = piece.position().left / 160;

    if (row == _row && col == _col + 1) {
        // Move left
        piece.animate({ left: "-=160px" }, 200);
        _col++;
    }
    else if (row == _row && col == _col - 1) {
        // Move right
        piece.animate({ left: "+=160px" }, 200);
        _col--;
    }
    else if (col == _col && row == _row + 1) {
        // Move up
        piece.animate({ top: "-=160px" }, 200);
        _row++;
    }
    else if (col == _col && row == _row - 1) {
        // Move down
        piece.animate({ top: "+=160px" }, 200);
        _row--;
    }
}