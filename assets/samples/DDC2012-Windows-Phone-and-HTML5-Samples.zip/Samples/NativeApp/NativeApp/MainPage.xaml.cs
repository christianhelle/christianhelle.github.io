﻿using System;
using System.Threading;
using Microsoft.Phone.Controls;

namespace NativeApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        private readonly Uri mainPage = new Uri("http://sandbox.commentor.dk");

        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            if (browser.Source != mainPage)
            {
                browser.InvokeScript("eval", "history.go(-1)");
                e.Cancel = true;
            }
            base.OnBackKeyPress(e);
        }
    }
}