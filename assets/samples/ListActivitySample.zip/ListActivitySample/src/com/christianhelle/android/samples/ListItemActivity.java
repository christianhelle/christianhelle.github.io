package com.christianhelle.android.samples;

public final class ListItemActivity {

}
