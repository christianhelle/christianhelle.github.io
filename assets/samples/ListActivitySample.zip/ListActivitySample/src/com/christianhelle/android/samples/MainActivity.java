package com.christianhelle.android.samples;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class MainActivity extends ListActivity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setListAdapter(new ListItemActivity(this, R.layout.list_item, createList()));
	}

	private List<ListItem> createList() {
		List<ListItem> list = new ArrayList<ListItem>();
		list.add(new ListItem("runtime one", "Maecenas praesent accumsan bibendum"));
		list.add(new ListItem("runtime two", "Dictumst eleifend facilisi faucibus"));
		list.add(new ListItem("runtime three", "Habitant inceptos interdum lobortis"));
		list.add(new ListItem("runtime four", "Nascetur pharetra placerat pulvinar"));
		return list;
	}

	class ListItem {
		public String lineOne;
		public String lineTwo;

		public ListItem(String lineOne, String lineTwo) {
			this.lineOne = lineOne;
			this.lineTwo = lineTwo;
		}
	}

	class ListItemActivity extends ArrayAdapter<ListItem> {
		private Activity context;
		private List<ListItem> items;

		public ListItemActivity(Activity context, int textViewResourceId, List<ListItem> items) {
			super(context, textViewResourceId, items);
			this.context = context;
			this.items = items;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				LayoutInflater inflater = context.getLayoutInflater();
				convertView = inflater.inflate(R.layout.list_item, parent, false);
				holder = new ViewHolder();
				holder.lineOne = (TextView) convertView.findViewById(R.id.lineOne);
				holder.lineTwo = (TextView) convertView.findViewById(R.id.lineTwo);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			ListItem item = items.get(position);
			holder.lineOne.setText(item.lineOne);
			holder.lineTwo.setText(item.lineTwo);
			return convertView;
		}
	}

	static class ViewHolder {
		TextView lineOne;
		TextView lineTwo;
	}
}