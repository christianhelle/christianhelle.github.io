﻿using System;

using System.Collections.Generic;
using System.Text;

namespace Garmin.NETCF
{
	/// <summary>
	/// Error Codes returned by the Garmin Mobile XT SDK
	/// </summary>
	public enum GarminErrorCodes : int
	{
		/// <summary>
		/// Success
		/// </summary>
		queErrNone = 0,
		/// <summary>
		/// Close() without having called open() first
		/// </summary>
		queErrNotOpen = 1,
		/// <summary>
		/// Invalid parameter passed to function
		/// </summary>
		queErrBadArg, 
		/// <summary>
		/// Out of memory
		/// </summary>
		queErrMemory,
		/// <summary>
		/// No data available
		/// </summary>
		queErrNoData,
		/// <summary>
		/// The Que API is already open
		/// </summary>
		queErrAlreadyOpen,
		/// <summary>
		/// The Que API is an incompatible version
		/// </summary>
		queErrInvalidVersion,
		/// <summary>
		/// There was an error communicating with the API
		/// </summary>
		queErrComm,         
		/// <summary>
		/// The command is unavailable
		/// </summary>
		queErrCmndUnavail,
		/// <summary>
		/// Library is still open
		/// </summary>
		queErrStillOpen,
		/// <summary>
		/// General failure
		/// </summary>
		queErrFail,
		/// <summary>
		/// Action cancelled by user
		/// </summary>
		queErrCancel,
		/// <summary>
		/// Relaunch needed to load the libraries
		/// </summary>
		queErrRelaunchNeeded
	}
}
