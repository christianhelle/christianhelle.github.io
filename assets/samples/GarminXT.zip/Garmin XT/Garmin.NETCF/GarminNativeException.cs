﻿using System;

using System.Collections.Generic;
using System.Text;

namespace Garmin.NETCF
{
	/// <summary>
	/// Exception containing native error descriptions
	/// </summary>
	[Serializable]
	public class GarminNativeException : Exception
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public GarminNativeException() { }

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="native_error">Error code</param>
		public GarminNativeException(GarminErrorCodes native_error) { }
		
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="message">Message describing the native exception</param>
		/// <param name="native_error">Error code</param>
		public GarminNativeException(
			string message, 
			GarminErrorCodes native_error) : base(message) { }
	}
}
