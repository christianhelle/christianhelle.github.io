﻿using System;

using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Garmin.NETCF
{
	internal class NativeMethods
	{
		[DllImport("Garmin.Native.dll")]
		internal static extern int CloseAPI();

		[DllImport("Garmin.Native.dll")]
		internal static extern int OpenNavigator();

		[DllImport("Garmin.Native.dll")]
		internal static extern int NavigateToAddress(
			string address, 
			string city, 
			string postalcode, 
			string state, 
			string country);

		[DllImport("Garmin.Native.dll")]
		internal static extern int NavigateToCoordinates(
			double latitude, 
			double longitude);

		[DllImport("Garmin.Native.dll")]
		internal static extern int ShowAddressOnMap(
			string address,
			string city,
			string postalcode,
			string state,
			string country);
	}
}
