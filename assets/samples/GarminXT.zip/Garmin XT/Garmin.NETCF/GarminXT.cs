﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Garmin.NETCF
{
	/// <summary>
	/// Managed wrapper for the Garmin Mobile SDK
	/// </summary>
	public class GarminXT : IDisposable
	{
		/// <summary>
		/// Creates an instance of the Garmin Mobile XT Wrapper
		/// </summary>
		public GarminXT()
		{

		}

		/// <summary>
		/// Closes the native API
		/// </summary>
		public void Dispose()
		{
			NativeMethods.CloseAPI();
		}

		/// <summary>
		/// Launches Garmin XT. Garmin Mobile XT must be running in order to call most API functions
		/// </summary>
		public void OpenNavigator()
		{
			GarminErrorCodes err = (GarminErrorCodes)NativeMethods.OpenNavigator();

			if (err != GarminErrorCodes.queErrNone) {
				ThrowGarminException(err);
			}
		}

		/// <summary>
		/// Plans a route from the current location to a specified address
		/// </summary>
		/// <param name="address">Street Address</param>
		/// <param name="city">City</param>
		/// <param name="postalcode">Zip or Postal Code</param>
		/// <param name="state">State</param>
		/// <param name="country">Country</param>
		public void NavigateToAddress(
			string address,
			string city,
			string postalcode,
			string state,
			string country)
		{
			GarminErrorCodes err = (GarminErrorCodes)NativeMethods.NavigateToAddress(
				address,
				city,
				postalcode,
				state,
				country);

			if (err != GarminErrorCodes.queErrNone) {
				ThrowGarminException(err);
			}
		}

		/// <summary>
		/// Plans a route from the current location to specified coordinates
		/// </summary>
		/// <param name="latitude">Latitude specified in WGS84 decimal format</param>
		/// <param name="longitude">Longitude specified in WGS84 decimal format</param>
		public void NavigateToCoordinates(double latitude, double longitude)
		{
			GarminErrorCodes err = (GarminErrorCodes)NativeMethods.NavigateToCoordinates(
				latitude,
				longitude);

			if (err != GarminErrorCodes.queErrNone) {
				ThrowGarminException(err);
			}
		}

		/// <summary>
		/// Displays a specified address on the map
		/// </summary>
		/// <param name="address">Street Address</param>
		/// <param name="city">City</param>
		/// <param name="postalcode">Zip or Postal Code</param>
		/// <param name="state">State</param>
		/// <param name="country">Country</param>
		public void ShowAddressOnMap(
			string address,
			string city,
			string postalcode,
			string state,
			string country)
		{
			GarminErrorCodes err = (GarminErrorCodes)NativeMethods.ShowAddressOnMap(
				address,
				city,
				postalcode,
				state,
				country);

			if (err != GarminErrorCodes.queErrNone) {
				ThrowGarminException(err);
			}
		}

		private GarminNativeException ThrowGarminException(GarminErrorCodes err)
		{
			string message = string.Empty;

			switch (err) {
				case GarminErrorCodes.queErrNotOpen:
					message = Properties.Resources.NOT_OPEN;
					break;
				case GarminErrorCodes.queErrBadArg:
					message = Properties.Resources.BAD_ARGUMENTS;
					break;
				case GarminErrorCodes.queErrMemory:
					message = Properties.Resources.OUT_OF_MEMORY;
					break;
				case GarminErrorCodes.queErrNoData:
					message = Properties.Resources.NO_DATA;
					break;
				case GarminErrorCodes.queErrAlreadyOpen:
					message = Properties.Resources.ALREADY_OPEN;
					break;
				case GarminErrorCodes.queErrInvalidVersion:
					message = Properties.Resources.INVALID_VERSION;
					break;
				case GarminErrorCodes.queErrComm:
					message = Properties.Resources.COMM_ERROR;
					break;
				case GarminErrorCodes.queErrCmndUnavail:
					message = Properties.Resources.CMD_UNAVAILABLE;
					break;
				case GarminErrorCodes.queErrStillOpen:
					message = Properties.Resources.API_STILL_OPEN;
					break;
				case GarminErrorCodes.queErrFail:
					message = Properties.Resources.GENERAL_FAILURE;
					break;
				case GarminErrorCodes.queErrCancel:
					message = Properties.Resources.ACTION_CANCELLED;
					break;
				case GarminErrorCodes.queErrRelaunchNeeded:
					message = Properties.Resources.RELAUNCH_NEEDED;
					break;
				default:
					break;
			}

			throw new GarminNativeException(message, err);
		}
	}
}
