// CWrapper.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "QueAPI.h"

#define EXPORTC extern "C" __declspec(dllexport)

long DecimalDegreesToSemicircles(double degrees);

BOOL APIENTRY DllMain( HANDLE hModule, 
											DWORD  ul_reason_for_call, 
											LPVOID lpReserved
											)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}

	return TRUE;
}

static void QueCallback(QueNotificationT8 aNotification)
{
}

EXPORTC int CloseAPI() 
{
	QueErrT16 err = QueAPIClose(QueCallback);
	return err;
}

EXPORTC int OpenNavigator() 
{
	QueErrT16 err = QueLaunchApp(queAppMap);
	return err;
}

EXPORTC int NavigateToAddress(const wchar_t *streetAddress,
															const wchar_t *city,
															const wchar_t *postalCode,
															const wchar_t *state,
															const wchar_t *country)
{
	QueErrT16 err = QueAPIOpen(QueCallback);
	if (err != gpsErrNone) {
		return err;
	}

	QueSelectAddressType address;
	QuePointHandle point = queInvalidPointHandle;	

	memset(&address, 0, sizeof(QueSelectAddressType));
	address.streetAddress = streetAddress;
	address.city = city;
	address.postalCode = postalCode;
	address.state = state;
	address.country = country;

	err = QueCreatePointFromAddress(&address, &point);
	if (err == queErrNone && point != queInvalidPointHandle) {
		err = QueRouteToPoint(point);
	}

	QueAPIClose(QueCallback);

	return err; 
}

long DecimalDegreesToSemicircles(double degrees)
{
	return degrees * (0x80000000 / 180);
}

EXPORTC int NavigateToCoordinates(double latitude, double longitude)
{
	QueErrT16 err = QueAPIOpen(QueCallback);
	if (err != gpsErrNone) {
		return err;
	}

	QuePointType point;
	QuePositionDataType position;

	memset(&position, 0, sizeof(QuePositionDataType));
	position.lat = DecimalDegreesToSemicircles(latitude);
	position.lon = DecimalDegreesToSemicircles(longitude);

	memset(&point, 0, sizeof(QuePointType));
	point.posn = position;
		
	QuePointHandle hPoint;
	memset(&hPoint, 0, sizeof(QuePointHandle));

	err = QueCreatePoint(&point, &hPoint);
	if (err == queErrNone && hPoint != queInvalidPointHandle) {
		err = QueRouteToPoint(hPoint);
	}

	QueAPIClose(QueCallback);

	return err; 
}

EXPORTC int ShowAddressOnMap(const wchar_t *streetAddress,
														 const wchar_t *city,
														 const wchar_t *postalCode,
														 const wchar_t *state,
														 const wchar_t *country)
{
	QueErrT16 err = QueAPIOpen(QueCallback);
	if (err != gpsErrNone) {
		return err;
	}

	QueSelectAddressType address;
	QuePointHandle point = queInvalidPointHandle;	

	memset(&address, 0, sizeof(QueSelectAddressType));
	address.streetAddress = streetAddress;
	address.city = city;
	address.postalCode = postalCode;
	address.state = state;
	address.country = country;

	err = QueCreatePointFromAddress(&address, &point);
	if (err == queErrNone && point != queInvalidPointHandle) {
		err = QueViewPointOnMap(point);
	}

	QueAPIClose(QueCallback);

	return err; 
}