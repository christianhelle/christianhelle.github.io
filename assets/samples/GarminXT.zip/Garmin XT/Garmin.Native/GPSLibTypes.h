/******************************************************************************
*
*   HEADER NAME:
*       GPSLib.h
*
*   DESCRIPTION:
*       Application Program Interface to the Global Positioning System Library.
*
*   Copyright 2002-2003 by Garmin Ltd. or its subsidiaries.
*
******************************************************************************/

#ifndef __GPSLIB_TYPES_H__
#define __GPSLIB_TYPES_H__

/*-----------------------------------------------------------------------------
                                GENERAL INCLUDES
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                                LITERAL CONSTANTS
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                                      TYPES
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------
GPS API Result Codes
----------------------------------------------------------*/
typedef uint8 GPSErrT8; enum
	{
	gpsErrNone			= 0,	/* success								        */
	gpsErrNotOpen		= 1,	/* unable to communicate with GPS API           */
	gpsErrBadArg		= 2,	/* invalid parameter passed to function         */
	gpsErrMemory		= 3,	/* out of memory						        */
	gpsErrNoData		= 4,	/* no data available				            */
	gpsErrAlreadyOpen	= 5,	/* the Que API is already open		            */
	gpsErrInvalidVersion= 6,	/* the Que API is an incompatable version       */
    gpsErrComm          = 7,    /* there was an error communicating with the API*/
    gpsErrCmndUnavail   = 8,    /* the command is unavaialbe                    */
	};

/*----------------------------------------------------------
Satellite Data Type
----------------------------------------------------------*/
typedef struct
    {
    uint8	        svid;       /* space vehicle identifier             */
    uint8           status;     /* status bitfield                      */
    sint16			snr;        /* signal to noise ratio * 100 (dB Hz)  */
    float			azimuth;    /* azimuth (radians)                    */
    float			elevation;  /* elevation (radians)                  */
    } GPSSatDataType;

#define gpsInvalidSVID      255     /* invalid space vehicle ID     */

// Satellite Status Bitfield Mask Values
#define gpsSatEphMask       1       /* ephemeris mask               */
#define gpsSatDifMask       2       /* differential mask            */
#define gpsSatUsedMask      4       /* used in solution mask        */
#define gpsSatRisingMask    8       /* rising mask                  */

/*----------------------------------------------------------
GPS Mode Type
----------------------------------------------------------*/
typedef uint8 GPSModeT8; enum
    {
    gpsModeOff      = 0,    /* GPS is off                           */
    gpsModeNormal   = 1,    /* continuous satellite tracking        */
    gpsModeBatSaver = 2,    /* periodic satellite tracking          */
    gpsModeSim      = 3,    /* simulated GPS information            */
    gpsModeExternal = 4,    /* external source of GPS information   */
    gpsModeCount    = 5     /* count of mode type enumerations      */
    };

/*----------------------------------------------------------
GPS Fix Type
----------------------------------------------------------*/
typedef uint8 GPSFixT8; enum
    {
    gpsFixUnusable  = 0,    /* failed integrity check               */
    gpsFixInvalid   = 1,    /* invalid or unavailable               */
    gpsFix2D        = 2,    /* 2 dimension                          */
    gpsFix3D        = 3,    /* 3 dimension                          */
    gpsFix2DDiff    = 4,    /* 2 dimension differential             */
    gpsFix3DDiff    = 5,    /* 3 dimension differential             */
    gpsFixCount     = 6     /* count of fix type enumerations       */
    };

/*----------------------------------------------------------
GPS Status Data Type
----------------------------------------------------------*/
typedef struct
    {
    GPSModeT8   mode;       /* mode type                                    */
    GPSFixT8    fix;        /* fix type                                     */
    sint16      filler2;    /* alignment padding                            */
    float       epe;        /* estimated position error, 1-sigma (meters)   */
    float       eph;        /* epe, horizontal only (meters)                */
    float       epv;        /* epe, vertical only (meters)                  */
    } GPSStatusDataType;

/*----------------------------------------------------------
GPS Position Data Type

The GPSPositionDataType uses integers to indicate latitude
and longitude in semicircles, where 2^31 semicircles equals
180 degrees. North latitudes and East longitudes are
indicated with positive numbers; South latitudes and West
longitudes are indicated with negative numbers. The
following formulas show how to convert between degrees and
semicircles:

    degrees = semicircles * ( 180 / 2^31 )
    semicircles = degrees * ( 2^31 / 180 )

    invalid semicircles = 2^31
    invalid altitude = 1.0e25

----------------------------------------------------------*/

typedef struct
    {
    sint32      lat;        /* latitude  (semicircles)                      */
    sint32      lon;        /* longitude (semicircles)                      */
    float       altMSL;     /* altitude above mean sea level (meters)       */
    float       altWGS84;   /* altitude above WGS84 ellipsoid (meters)      
                                NOTE: If WGS84 unknown, gpsInvalidAltitude 
                                is returned                                 */
    } GPSPositionDataType;

#define gpsInvalidSemicircles   ( 0x80000000 )
#define gpsInvalidAltitude      ( (float) 1.0e25 )

/*----------------------------------------------------------
GPS Velocity Data Type
----------------------------------------------------------*/
typedef struct
    {
    float       east;       /* east (m/s)                           */
    float       north;      /* north (m/s)                          */
    float       up;         /* upwards (m/s)                        */
    float       track;      /* track (radians)                      */
    float       speed;      /* speed, horizontal only (m/s)         */
    } GPSVelocityDataType;

/*----------------------------------------------------------
GPS Time Data Type
----------------------------------------------------------*/
typedef struct
    {
    unsigned __int32      seconds;        /* seconds since midnight (UTC)     */
    unsigned __int32      fracSeconds;    /* 0..1 second * 2^32               */
    } GPSTimeDataType;

/*----------------------------------------------------------
GPS Comprehensive Data Type
----------------------------------------------------------*/
typedef struct
    {
    GPSStatusDataType       status;
    GPSPositionDataType     position;
    GPSVelocityDataType     velocity;
    GPSTimeDataType         time;
    } GPSPVTDataType;

/*----------------------------------------------------------
GPS CPO Data Types
----------------------------------------------------------*/
typedef struct
    {
    double      lat;
    double      lon;
	double		tow;
	float		alt;
	float		epe;
	float		eph;
	float		epv;
	float		msl;
    float       east;
    float       north;
    float       up;
	uint32		grmn_days;
	uint16		fix;
	uint16		leap_scnds;
    } GPSCarrierPhaseOutputPositionDataType;

typedef struct
    {
    double          pr;         /* pseudorange                      */
    uint32          cycles;     /* cycles                           */
    uint16          phse;       /* carrier phase, 1/2048 cycle      */
    uint8           svid;       /* satellite id                     */
    uint8           snr_dbhz;   /* snr in dB*Hz                     */
    boolean         slp_dtct;   /* cycle slip detected              */
    boolean         valid;      /* pseudorange valid flag           */
    } GPSSatelliteInstRecordDataType;

typedef struct                  /* Data Instrumentation Record      */
    {                           /*  (test only)                     */
    sint32          epoch;      /* data epoch counter               */
    uint32          wrd;        /* current SDM word                 */
    uint8           svid;       /* satellite id                     */
    } GPSSatelliteEphInstDataType;

/*-----------------------------------------------------------------------------
                                   END OF FILE
-----------------------------------------------------------------------------*/

#endif  /* __GPSLIB_TYPES_H__ */
