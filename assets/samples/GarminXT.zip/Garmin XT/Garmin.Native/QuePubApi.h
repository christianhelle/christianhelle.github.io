/******************************************************************************
*
*   HEADER NAME:
*       QueAPI.h
*
*   DESCRIPTION:
*       Application Program Interface to the Que technology
*
*   Copyright 2002-2005 by Garmin Ltd. or its subsidiaries.
*
******************************************************************************/

#ifndef __QuePubAPI_H__
#define __QuePubAPI_H__

/*-----------------------------------------------------------------------------
                                GENERAL INCLUDES
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                                LITERAL CONSTANTS
-----------------------------------------------------------------------------*/

#define queAPIVersion       150       /* Que API version 1.50     */

/*-----------------------------------------------------------------------------
                                      TYPES
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------
Basic types
----------------------------------------------------------*/
typedef unsigned char           uint8;
typedef unsigned short int      uint16;
typedef unsigned long int       uint32;
typedef signed char             sint8;
typedef signed short int        sint16;
typedef signed long int         sint32;

/*----------------------------------------------------------
Error range start
----------------------------------------------------------*/

#define firstQueAPIErr      1

/*----------------------------------------------------------
Notification information
----------------------------------------------------------*/
typedef uint8 QueNotificationT8; enum
    {
    queLocationChange       = 0,    /* The GPS position has changed                 */
    queStatusChange         = 1,    /* The GPS status has changed                   */
    queLostFix              = 2,    /* The quality of the GPS position computation
                                        has become less than two dimensional        */
    queSatDataChange        = 3,    /* The GPS satellite data has changed           */
    queModeChange           = 4,    /* The GPS mode has changed                     */
    queEvent                = 5,    /* An event has occurred (sunrise/set, etc.)    */
    queCPOPositionChange    = 6,    /* The GPS CPO position data has been updated 
                                       (M3/M5 only)                                 */
    queSatelliteInstChange  = 7,    /* The GPS CPO satellite data has been updated 
                                       (M3/M5 only)                                 */
    queNavigationEvent      = 8,    /* The users navigation state changed 
                                       (Added in 1.50)                              */

    queUserNotificationCount,       /* Count of change type enumerations(user only) */
    };

/*----------------------------------------------------------
Notification callback signature
----------------------------------------------------------*/
typedef void (CALLBACK* QueNotificationCallback)( QueNotificationT8 );


/*-----------------------------------------------------------------------------
                                   SHARED TYPES
-----------------------------------------------------------------------------*/

#include "GPSLibTypes.h"
#include "QueAPITypes.h"

/*-----------------------------------------------------------------------------
                                   PROCEDURES
-----------------------------------------------------------------------------*/

#ifdef QUEAPI_EXPORTS
#define QueAPIExport __declspec(dllexport)
#elif defined QUEAPI_SERVER
#define QueAPIExport
#else
#define QueAPIExport __declspec(dllimport)
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
                             OPEN/CLOSE PROCEDURES
-----------------------------------------------------------------------------*/

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueAPIOpen - Open QueAPI
*
*   DESCRIPTION:
*       Opens QueAPI and prepares it for use. Called by any application or
*       library that wants to use the services that QueAPI provides.
*
*       QueAPIOpen *must* be called before calling any other GPS* or Que*
*       functions, with the exception of QueGetAPIVersion.
*       If an error occurs during initialization, QueAPIOpen returns the
*       error code and exits cleanly.
*
*********************************************************************/
QueAPIExport QueErrT16 QueAPIOpen( QueNotificationCallback callback );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueAPIClose - Close QueAPI
*
*   DESCRIPTION:
*       Closes QueAPI and disposes of the global data memory if
*       required. Called by any application or library that's been
*       using QueAPI and is now finished with it.  Supply the callback
*       function supplied in the corresponding QueAPIOpen call.
*
*********************************************************************/
QueAPIExport QueErrT16 QueAPIClose( QueNotificationCallback callback );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetApiVersion - Get QueAPI API Version
*
*   DESCRIPTION:
*       Returns the QueAPIVersion constant.
*
*   NOTES:
*       The Que API dosen't need to be opened to call this function.
*
*********************************************************************/
QueAPIExport uint16 QueGetAPIVersion();

/*-----------------------------------------------------------------------------
                             GPS DATA PROCEDURES
-----------------------------------------------------------------------------*/

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetMaxSatellites - Get the Maximum Number of Satellites
*
*   DESCRIPTION:
*       Returns the maximum number of satellites that are currently supported.
*
*       The value returned by this routine should be used in the dynamic
*       allocation of the array of satellites (GPSSatDataType).
*
*********************************************************************/
QueAPIExport uint8 GPSGetMaxSatellites();

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetPosition - Get Current Position Data
*
*   DESCRIPTION:
*       Returns a GPSPositionDataType structure with the latest position
*       from the GPS.
*
*       If the return value is not gpsErrNone the data should be
*       considered invalid.
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetPosition( GPSPositionDataType *position );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetPVT - Get Current Position/Velocity/Time Data
*
*   DESCRIPTION:
*       Returns a GPSPVTDataType structure with the latest position,
*       velocity, and time data from the GPS.
*
*       If p_pvt->status.fix is equal to gpsFixUnusable or
*       gpsFixInvalid, the rest of the data in the structure should
*       be assumed to be invalid.
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetPVT( GPSPVTDataType *pvt );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetSatellites - Get Current Satellite Data
*
*   DESCRIPTION:
*       Returns a GPSSatDataType structure with the latest satellite
*       information from the GPS. The data must be an array of at least
*       GPSGetMaxSatellites items!
*
*   NOTES:
*       an M3/M5, we expect SNR to be between 30dB and 50dB. 
*       On an M4 we expect SNR to be between 15dB and 40dB.
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetSatellites( GPSSatDataType *sat );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetStatus - Get Current Status Data
*
*   DESCRIPTION:
*       Returns a GPSStatusDataType structure with the latest status
*       from the GPS.
*
*       If the return value is not gpsErrNone the data should be
*       considered invalid.
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetStatus( GPSStatusDataType *status );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetTime - Get Current Time Data
*
*   DESCRIPTION:
*       Returns a GPSTimeDataType structure with the latest time
*       from the GPS.
*
*       If the return value is not gpsErrNone the data should be
*       considered invalid.
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetTime( GPSTimeDataType *time );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetVelocity - Get Current Velocity Data
*
*   DESCRIPTION:
*       Returns a GPSVelocityDataType structure with the latest velocity
*       from the GPS.
*
*       If the return value is not gpsErrNone the data should be
*       considered invalid.
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetVelocity( GPSVelocityDataType *velocity );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSSetMode - Set the Current GPS Mode
*
*   DESCRIPTION:
*       Set the GPS mode. If the mode isn't supported queErrBadArg
*       is returned
*
*   NOTES:
*       Added in Que API version 1.50
*
*********************************************************************/
QueAPIExport QueErrT16 GPSSetMode( GPSModeT8 mode );

/*-----------------------------------------------------------------------------
                           GPS CPO DATA PROCEDURES
                              (iQue M3/M5 only)
-----------------------------------------------------------------------------*/

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetCPOPositionData
*
*   DESCRIPTION:
*
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetCPOPositionData( GPSCarrierPhaseOutputPositionDataType *position );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetSatelliteInstRecordData
*
*   DESCRIPTION:
*       The sats inst data must be an array of at least
*       GPSGetMaxSatellites items!
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetSatelliteInstRecordData( double *rcvr_tow, uint16 *rcvr_wn, GPSSatelliteInstRecordDataType *sats_inst );

/*********************************************************************
*
*   PROCEDURE NAME:
*       GPSGetSatelliteEphInstData
*
*   DESCRIPTION:
*       The sats inst data must be an array of 24 items!
*
*********************************************************************/
QueAPIExport QueErrT16 GPSGetSatelliteEphInstData( GPSSatelliteEphInstDataType eph_inst[24], uint8* valid_sats );

/*-----------------------------------------------------------------------------
                        PROGRAM LAUNCH PROCEDURES
-----------------------------------------------------------------------------*/

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueLaunchApp - Launch given app, or bring it to the foreground
*
*   DESCRIPTION:
*       Launches the specified application if it isn't already running
*       and brings to the foreground.
*
*   NOTES:
*       The Que Lib dosen't need to be opened to call this function.
*       Added in Que API version 1.50
*
*********************************************************************/
QueAPIExport QueErrT16 QueLaunchApp( QueAppT8 app );

/*-----------------------------------------------------------------------------
                      GENERAL INFORMATION PROCEDURES
-----------------------------------------------------------------------------*/

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetNearestAddress - Get Nearest Address Data
*
*   DESCRIPTION:
*       Returns a structure with the nearest address.
*
*       If the return value is not queErrNone the data should be
*       considered invalid.
*
*   NOTES:
*       Added in version 1.40
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetNearestAddress
    ( 
    QueAddressType*     aAddress            // in:  Address
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetAddressString - Get Current Address Data
*
*   DESCRIPTION:
*       Returns a string with the latest address.
*
*       If the return value is not queErrNone the data should be
*       considered invalid.
*
*   NOTES:
*       Added in version 1.30
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetAddressString
    ( 
    TCHAR *aString,
    uint16 aStringLen
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetAddress - Get Current Address Data
*
*   DESCRIPTION:
*       Returns a string with the latest address. The caller is
*       responsible for freeing the memory for the string by calling
*       LocalFree(*aAddress).
*
*       If the return value is not queErrNone the data should be
*       considered invalid.
*
*   NOTES:
*       Deprecated in version 1.30
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetAddress( TCHAR **aAddress );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetDrvRteStatusString - Get Current Driving/Routing Status
*
*   DESCRIPTION:
*       Returns a string with the latest driving/routing status
*       The caller is responsible for freeing the memory
*       for the string by calling LocalFree(*aStatus).
*
*       If the return value is not queErrNone the data should be
*       considered invalid.
*
*   NOTES:
*       Added in version 1.30
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetDrvRteStatusString
    ( 
    TCHAR *aString,
    uint16 aStringLen    
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetDrvRteStatus - Get Current Driving/Routing Status
*
*   DESCRIPTION:
*       Returns a string with the latest driving/routing status
*       The caller is responsible for freeing the memory
*       for the string by calling LocalFree(*aStatus).
*
*       If the return value is not queErrNone the data should be
*       considered invalid.
*
*   NOTES:
*       Deprecated in version 1.30
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetDrvRteStatus( TCHAR **aStatus );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetStringFromLocation - Get Text String for given location
*
*   DESCRIPTION:
*       Returns the given location as a text string
*       If the return value is not queErrNone the data should be
*       considered invalid. If the position is NULL, the current
*       position is used.
*       The caller is responsible for freeing the memory
*       for the string by calling LocalFree(*aStatus).
*
*   NOTES:
*       Added in version 1.30
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetStringFromLocation
    (
    const QuePositionDataType*  aPosn,      // in:  Position
    TCHAR *aString,                         // out: string
    uint16 aStringLen                       // in:  string length of buffer
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetLocationString - Get Text String for given location
*
*   DESCRIPTION:
*       Returns the given location as a text string
*       If the return value is not queErrNone the data should be
*       considered invalid. If the position is NULL, the current
*       position is used.
*       The caller is responsible for freeing the memory
*       for the string by calling LocalFree(*aStatus).
*
*   NOTES:
*       Deprecated in version 1.30
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetLocationString
    (
    const QuePositionDataType*  aPosn,      // in:  Position
    TCHAR**                     aString     // out: Pointer to string containing position
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetSunRiseSet - Get sunrise and sunset times for given location
*
*   DESCRIPTION:
*       Returns a QueRiseSetType structure for the given location.
*
*       If the return value is not queErrNone the data should be
*       considered invalid.
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetSunRiseSet
    (
    const QuePositionDataType * aPosition,  // in:  position for which to calculate rise or set. If null current posn used.
    const QueGarminTimeT32 *    aDate,      // in:  date for which to calculate rise or set. If null current time used
    QueRiseSetType *            aRiseSet    // out: sunrise/sunset info
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetMoonRiseSet - Get moonrise and moonset times for given location
*
*   DESCRIPTION:
*       Returns a QueRiseSetType structure for the given location.
*
*       If the return value is not queErrNone the data should be
*       considered invalid.  It is valid for this function to retun
*       queTimeInvalid in the rise member of the aRiseSet parameter
*       if the moon does not rise that day or in the set member
*       of the aRiseSet parameter if the moon does not set that day.
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetMoonRiseSet
    (
    const QuePositionDataType * aPosition,  // in:  position for which to calculate rise or set. If null current posn used.
    const QueGarminTimeT32 *    aDate,      // in:  date for which to calculate rise or set. If null current time used
    QueRiseSetType *            aRiseSet    // out: moonrise/moonset info
    );

/*-----------------------------------------------------------------------------
                        TIME CONVERSION PROCEDURES
-----------------------------------------------------------------------------*/

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueConvertGarminToSystemTime - Convert from Garmin time to system time
*
*   DESCRIPTION:
*       Converts the given Garmin time value to a SYSTEMTIME structure.
*       If the input time is invalid, the SYSETMTIME contains all 0's.
*
*********************************************************************/
QueAPIExport QueErrT16 QueConvertGarminToSystemTime( QueGarminTimeT32 input, SYSTEMTIME* output );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueConvertGarminToSystemTime - Convert from Garmin time to system time
*
*   DESCRIPTION:
*       Converts the given SYSETMTIME value to a QueGarminTimeT32 value.
*       If the input time is invalid, the output is 0xFFFFFFFF.
*
*********************************************************************/
QueAPIExport QueErrT16 QueConvertSystemToGarminTime( const SYSTEMTIME* input, QueGarminTimeT32* output );

/*-----------------------------------------------------------------------------
                             QUE POINT PROCEDURES
-----------------------------------------------------------------------------*/

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueCreatePoint - Create a point handle with given data
*
*   DESCRIPTION:
*
*
*********************************************************************/
QueAPIExport QueErrT16 QueCreatePoint( const QuePointType* point, QuePointHandle* handle );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueClosePoint - Close the point
*
*   DESCRIPTION:
*       This procedures closes a QuePointHandle to a given point.
*
*********************************************************************/
QueAPIExport QueErrT16 QueClosePoint( QuePointHandle point );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueGetPointInfo - Get the point info for the given point handle
*
*   DESCRIPTION:
*
*
*********************************************************************/
QueAPIExport QueErrT16 QueGetPointInfo( QuePointHandle point, QuePointType* point_data );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueSerializePoint - Serialze the point for long term storage.
*
*   DESCRIPTION:
*       Returns all data needed to recreate the point handle to caller.
*       Point can then be reconstituted by a call to QueDeserializePoint.
*       The function returns the size of the serialized data. If the
*       buffer passed in is not big enough, no data will be copied.
*
*********************************************************************/
QueAPIExport uint32 QueSerializePoint( QuePointHandle point, void* point_data, uint32 point_data_sz );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueDeserializePoint - Deserialze the point from long term storage.
*
*   DESCRIPTION:
*       Recreates a handle to a point from serialized data.
*
*********************************************************************/
QueAPIExport QueErrT16 QueDeserializePoint( void* point_data, uint32 point_data_sz, QuePointHandle* handle );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueRouteDetour - Create a detour
*
*   DESCRIPTION:
*       Cause the current route to avoid the next aDistance meters
*       of the route.
*
*   NOTES:
*       Added in version 1.50
*
*********************************************************************/
QueAPIExport QueErrT16 QueRouteDetour( float aDistance );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueRouteIsActive - Is route active
*
*   DESCRIPTION:
*       aIsActive set to TRUE if the user is currently navigating 
*       a route.
*
*   NOTES:
*       Added in version 1.50
*
*********************************************************************/
QueAPIExport QueErrT16 QueRouteIsActive( boolean* aIsActive );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueRouteStop - Stop routing to a point
*
*   DESCRIPTION:
*       Stop the active route
*
*   NOTES:
*       Added in version 1.50
*
*********************************************************************/
QueAPIExport QueErrT16 QueRouteStop();

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueRouteToPoint - Route to a point
*
*   DESCRIPTION:
*       Create a route from your current location to the given point
*
*********************************************************************/
QueAPIExport QueErrT16 QueRouteToPoint( QuePointHandle point );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueRouteToVias - Route to a series of points
*
*   DESCRIPTION:
*       Create a route from your current location to the given points
*
*   NOTES:
*       Added in Que API version 1.50
*
*********************************************************************/
QueAPIExport QueErrT16 QueRouteToVias( const QuePointHandle* points, uint32 point_count, QueRouteSortT8 sort_type );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueViewPointOnMap - View a point on the map
*
*   DESCRIPTION:
*       Show the details page for this point.
*
*   NOTES:
*       This function brings up the details page in Que's process.
*
*********************************************************************/
QueAPIExport QueErrT16 QueViewPointOnMap( QuePointHandle point );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueViewPointDetails - Shows a details page for the point
*
*   DESCRIPTION:
*       Bring up QueMap with the given point selected
*
*   NOTES:
*       This function brings up the details page in Que's process.
*
*********************************************************************/
QueAPIExport QueErrT16 QueViewPointDetails( QuePointHandle point );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueSelectPointFromMap - Select a point using the map dialog
*
*   DESCRIPTION:
*       This function blocks until the user selects a point. If no point
*       is selected, queInvalidPointHandle is returned.
*
*   NOTES:
*       The value of orig can be queInvalidPointHandle if you don't
*       want to move a point.
*
*********************************************************************/
QueAPIExport QueErrT16 QueSelectPointFromMap
    (
    HWND            parent, // in:  Handle to parent window. NULL if no parent.
    QuePointHandle  orig,   // in:  Handle to point to move.
    QuePointHandle* point   // out: Handle to selected point. Must be closed with QueClosePoint.
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueSelectPointFromFind - Select a point using the find dialog
*
*   DESCRIPTION:
*       This function blocks until the user selects a point. If no point
*       is selected, queInvalidPointHandle is returned.
*
*********************************************************************/
QueAPIExport QueErrT16 QueSelectPointFromFind
    (
    HWND            parent, // in:  Handle to parent window. NULL if no parent.
    QuePointHandle* point   // out: Handle to selected point. Must be closed with QueClosePoint.
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueSelectAddressFromFind - Select a point using QueFind's address dialog
*
*   DESCRIPTION:
*       This function blocks until the user selects a point. If no point
*       is selected, queInvalidPointHandle is returned.
*
*********************************************************************/
QueAPIExport QueErrT16 QueSelectAddressFromFind
    (
    HWND                    parent, // in:  Handle to parent window. NULL if no parent.
    QueSelectAddressType*   addr,   // in:  Address data to search on.
    QuePointHandle*         point   // out: Handle to selected point. Must be closed with QueClosePoint.
    );

/*********************************************************************
*
*   PROCEDURE NAME:
*       QueCreatePointFromAddress - Create a point from the given address
*
*   DESCRIPTION:
*       This attempt to find a point for the given address. If no point
*       is found, queInvalidPointHandle is returned.
*
*********************************************************************/
QueAPIExport QueErrT16 QueCreatePointFromAddress
    (
    QueSelectAddressType*   addr,   // in:  Address data to search on.
    QuePointHandle*         point   // out: Handle to selected point. Must be closed with QueClosePoint.
    );

#ifdef __cplusplus
}
#endif

#endif  /* __QuePubAPI_H__ */

