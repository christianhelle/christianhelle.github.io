/******************************************************************************
*
*   HEADER NAME:
*       QueAPI.h
*
*   DESCRIPTION:
*       Application Program Interface to the Que technology
*
*   Copyright 2002-2003 by Garmin Ltd. or its subsidiaries.
*
******************************************************************************/

#ifndef __QueAPI_H__
#define __QueAPI_H__

#include "QuePubAPI.h"

#endif  /* __QueAPI_H__ */
