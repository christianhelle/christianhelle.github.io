/******************************************************************************
*
*   HEADER NAME:
*       QueApiTypes.h
*
*   DESCRIPTION:
*       Types for the Application Program Interface to the Que technology
*
*   Copyright 2004-2007 by Garmin Ltd. or its subsidiaries.
*
******************************************************************************/

#ifndef __QUEAPITYPES_H__
#define __QUEAPITYPES_H__

/*-----------------------------------------------------------------------------
                                GENERAL INCLUDES
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                                LITERAL CONSTANTS
-----------------------------------------------------------------------------*/

#define QUE_ADDR_BUF_LENGTH 50
#define QUE_POST_BUF_LENGTH 11

/*-----------------------------------------------------------------------------
                                      TYPES
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------
Que API Result Codes
----------------------------------------------------------*/
typedef uint16 QueErrT16; enum
    {
    queErrNone    = 0,              /* Success                                       */
    queErrNotOpen = firstQueAPIErr, /* Close() without having called open() first    */
    queErrBadArg,                   /* Invalid parameter passed to function          */
    queErrMemory,                   /* Out of memory                                 */
    queErrNoData,                   /* No data available                             */
    queErrAlreadyOpen,              /* The Que API is already open                   */
    queErrInvalidVersion,           /* The Que API is an incompatible version        */
    queErrComm,                     /* There was an error communicating with the API */
    queErrCmndUnavail,              /* The command is unavailable                    */
    queErrStillOpen,                /* Library is still open                         */
    queErrFail,                     /* General failure                               */
    queErrCancel,                   /* Action cancelled by user                      */
    queErrRelaunchNeeded            /* Relaunch needed to load the libraries         */
    };

/*----------------------------------------------------------
Que Time Types
----------------------------------------------------------*/

#define queTimeInvalid  ( 0xFFFFFFFF )

/* Garmin Time. Seconds since (TODO)                                                 */
typedef uint32 QueGarminTimeT32;

/*----------------------------------------------------------
Que Sun/Moon Rise and Set Data Type
----------------------------------------------------------*/
typedef struct
    {
    QueGarminTimeT32    rise;      /* Rise time */
    QueGarminTimeT32    set;       /* Set time  */
    uint8               isDay;     /* Non-zero if day, zero if night */
    } QueRiseSetType;

/*----------------------------------------------------------
Que Point Types
----------------------------------------------------------*/

#define queInvalidSemicircles   ( ( sint32 ) 0x80000000 )
#define queInvalidAltitude      ( ( float ) 1.0e25 )
#define queInvalidPointHandle   ( NULL )
#define quePointIdLen           ( 25 )
#define queInvalidSymbol        ( 0xFFFF )

typedef struct
    {
    sint32      lat;        /* Latitude  (semicircles)                      */
    sint32      lon;        /* Longitude (semicircles)                      */
    float       altMSL;     /* Altitude above mean sea level (meters)       */
    } QuePositionDataType;

typedef uint32 QuePointHandle;

typedef uint16 QueSymbolT16; enum
    {
    /*-----------------------------------------------------------
    The symbol type is used to indicate the symbol for a waypoint.
    Please refer to "Garmin GPS Interface Specification" section 7.4.9
    -----------------------------------------------------------*/

    /*---------------------------------------------------------------
    Symbols for marine (group 0...0-8191...bits 15-13=000).
    ---------------------------------------------------------------*/
    SYM_ANCHOR          =   0,  /* white anchor symbol              */
    SYM_BELL            =   1,  /* white bell symbol                */
    SYM_DIAMOND_GRN     =   2,  /* green diamond symbol             */
    SYM_DIAMOND_RED     =   3,  /* red diamond symbol               */
    SYM_DIVE1           =   4,  /* diver down flag 1                */
    SYM_DIVE2           =   5,  /* diver down flag 2                */
    SYM_DOLLAR          =   6,  /* white dollar symbol              */
    SYM_FISH            =   7,  /* white fish symbol                */
    SYM_FUEL            =   8,  /* white fuel symbol                */
    SYM_HORN            =   9,  /* white horn symbol                */
    SYM_HOUSE           =  10,  /* white house symbol               */
    SYM_KNIFE           =  11,  /* white knife & fork symbol        */
    SYM_LIGHT           =  12,  /* white light symbol               */
    SYM_MUG             =  13,  /* white mug symbol                 */
    SYM_SKULL           =  14,  /* white skull and crossbones symbol*/
    SYM_SQUARE_GRN      =  15,  /* green square symbol              */
    SYM_SQUARE_RED      =  16,  /* red square symbol                */
    SYM_WBUOY           =  17,  /* white buoy waypoint symbol       */
    SYM_WPT_DOT         =  18,  /* waypoint dot                     */
    SYM_WRECK           =  19,  /* white wreck symbol               */
    SYM_NULL            =  20,  /* null symbol (transparent)        */
    SYM_MOB             =  21,  /* man overboard symbol             */

    /*------------------------------------------------------
    marine navaid symbols
    ------------------------------------------------------*/
    SYM_BUOY_AMBR       =  22,  /* amber map buoy symbol            */
    SYM_BUOY_BLCK       =  23,  /* black map buoy symbol            */
    SYM_BUOY_BLUE       =  24,  /* blue map buoy symbol             */
    SYM_BUOY_GRN        =  25,  /* green map buoy symbol            */
    SYM_BUOY_GRN_RED    =  26,  /* green/red map buoy symbol        */
    SYM_BUOY_GRN_WHT    =  27,  /* green/white map buoy symbol      */
    SYM_BUOY_ORNG       =  28,  /* orange map buoy symbol           */
    SYM_BUOY_RED        =  29,  /* red map buoy symbol              */
    SYM_BUOY_RED_GRN    =  30,  /* red/green map buoy symbol        */
    SYM_BUOY_RED_WHT    =  31,  /* red/white map buoy symbol        */
    SYM_BUOY_VIOLET     =  32,  /* violet map buoy symbol           */
    SYM_BUOY_WHT        =  33,  /* white map buoy symbol            */
    SYM_BUOY_WHT_GRN    =  34,  /* white/green map buoy symbol      */
    SYM_BUOY_WHT_RED    =  35,  /* white/red map buoy symbol        */
    SYM_DOT             =  36,  /* white dot symbol                 */
    SYM_RBCN            =  37,  /* radio beacon symbol              */
    /*------------------------------------------------------
    leave space for more navaids (up to 128 total)
    ------------------------------------------------------*/

    SYM_BOAT_RAMP       = 150,  /* boat ramp symbol                 */
    SYM_CAMP            = 151,  /* campground symbol                */
    SYM_RESTROOMS       = 152,  /* restrooms symbol                 */
    SYM_SHOWERS         = 153,  /* shower symbol                    */
    SYM_DRINKING_WTR    = 154,  /* drinking water symbol            */
    SYM_PHONE           = 155,  /* telephone symbol                 */
    SYM_1ST_AID         = 156,  /* first aid symbol                 */
    SYM_INFO            = 157,  /* information symbol               */
    SYM_PARKING         = 158,  /* parking symbol                   */
    SYM_PARK            = 159,  /* park symbol                      */
    SYM_PICNIC          = 160,  /* picnic symbol                    */
    SYM_SCENIC          = 161,  /* scenic area symbol               */
    SYM_SKIING          = 162,  /* skiing symbol                    */
    SYM_SWIMMING        = 163,  /* swimming symbol                  */
    SYM_DAM             = 164,  /* dam symbol                       */
    SYM_CONTROLLED      = 165,  /* controlled area symbol           */
    SYM_DANGER          = 166,  /* danger symbol                    */
    SYM_RESTRICTED      = 167,  /* restricted area symbol           */
    SYM_NULL_2          = 168,  /* null symbol                      */
    SYM_BALL            = 169,  /* ball symbol                      */
    SYM_CAR             = 170,  /* car symbol                       */
    SYM_DEER            = 171,  /* deer symbol                      */
    SYM_SHPNG_CART      = 172,  /* shopping cart symbol             */
    SYM_LODGING         = 173,  /* lodging symbol                   */
    SYM_MINE            = 174,  /* mine symbol                      */
    SYM_TRAIL_HEAD      = 175,  /* trail head symbol                */
    SYM_TRUCK_STOP      = 176,  /* truck stop symbol                */
    SYM_USER_EXIT       = 177,  /* user exit symbol                 */
    SYM_FLAG            = 178,  /* flag symbol                      */
    SYM_CIRCLE_X        = 179,  /* circle with x in the center      */
    SYM_OPEN_24HR       = 180,  /* open 24 hours symbol             */
    SYM_FHS_FACILITY    = 181,  /* Fishing Hot Spots� Facility      */
    SYM_BOT_COND        = 182,  /* Bottom Conditions                */
    SYM_TIDE_PRED_STN   = 183,  /* Tide/Current Prediction Station  */
    SYM_ANCHOR_PROHIB   = 184,  /* anchor prohibited symbol         */
    SYM_BEACON          = 185,  /* beacon symbol                    */
    SYM_COAST_GUARD     = 186,  /* coast guard symbol               */
    SYM_REEF            = 187,  /* reef symbol                      */
    SYM_WEEDBED         = 188,  /* weed bed symbol                  */
    SYM_DROPOFF         = 189,  /* drop off symbol                  */
    SYM_DOCK            = 190,  /* dock symbol                      */
    SYM_MARINA          = 191,  /* marina symbol                    */
    SYM_BAIT_TACKLE     = 192,  /* bait and tackle symbol           */
    SYM_STUMP           = 193,  /* stump symbol                     */

    /*-----------------------------------------------------------
    Symbols for user-customizable waypoint images (7680-8191)
    -----------------------------------------------------------*/
    SYM_FRST_USER_WSYM  = 7680, /* first user-customizable symbol   */
    SYM_LAST_USER_WSYM  = 8191, /* last user-customizable symbol    */

    /*---------------------------------------------------------------
    Symbols for land (group 1...8192-16383...bits 15-13=001).
    ---------------------------------------------------------------*/
    SYM_IS_HWY              = 8192,  /* interstate hwy symbol            */
    SYM_US_HWY              = 8193,  /* us hwy symbol                    */
    SYM_ST_HWY              = 8194,  /* state hwy symbol                 */
    SYM_MI_MRKR             = 8195,  /* mile marker symbol               */
    SYM_TRCBCK              = 8196,  /* TracBack (feet) symbol           */
    SYM_GOLF                = 8197,  /* golf symbol                      */
    SYM_SML_CTY             = 8198,  /* small city symbol                */
    SYM_MED_CTY             = 8199,  /* medium city symbol               */
    SYM_LRG_CTY             = 8200,  /* large city symbol                */
    SYM_FREEWAY             = 8201,  /* intl freeway hwy symbol          */
    SYM_NTL_HWY             = 8202,  /* intl national hwy symbol         */
    SYM_CAP_CTY             = 8203,  /* capitol city symbol (star)       */
    SYM_AMUSE_PK            = 8204,  /* amusement park symbol            */
    SYM_BOWLING             = 8205,  /* bowling symbol                   */
    SYM_CAR_RENTAL          = 8206,  /* car rental symbol                */
    SYM_CAR_REPAIR          = 8207,  /* car repair symbol                */
    SYM_FASTFOOD            = 8208,  /* fast food symbol                 */
    SYM_FITNESS             = 8209,  /* fitness symbol                   */
    SYM_MOVIE               = 8210,  /* movie symbol                     */
    SYM_MUSEUM              = 8211,  /* museum symbol                    */
    SYM_PHARMACY            = 8212,  /* pharmacy symbol                  */
    SYM_PIZZA               = 8213,  /* pizza symbol                     */
    SYM_POST_OFC            = 8214,  /* post office symbol               */
    SYM_RV_PARK             = 8215,  /* RV park symbol                   */
    SYM_SCHOOL              = 8216,  /* school symbol                    */
    SYM_STADIUM             = 8217,  /* stadium symbol                   */
    SYM_STORE               = 8218,  /* dept. store symbol               */
    SYM_ZOO                 = 8219,  /* zoo symbol                       */
    SYM_GAS_PLUS            = 8220,  /* convenience store symbol         */
    SYM_FACES               = 8221,  /* live theater symbol              */
    SYM_RAMP_INT            = 8222,  /* ramp intersection symbol         */
    SYM_ST_INT              = 8223,  /* street intersection symbol       */
    SYM_WEIGH_STTN          = 8226,  /* inspection/weigh station symbol  */
    SYM_TOLL_BOOTH          = 8227,  /* toll booth symbol                */
    SYM_ELEV_PT             = 8228,  /* elevation point symbol           */
    SYM_EX_NO_SRVC          = 8229,  /* exit without services symbol     */
    SYM_GEO_PLACE_MM        = 8230,  /* Geographic place name, man-made  */
    SYM_GEO_PLACE_WTR       = 8231,  /* Geographic place name, water     */
    SYM_GEO_PLACE_LND       = 8232,  /* Geographic place name, land      */
    SYM_BRIDGE              = 8233,  /* bridge symbol                    */
    SYM_BUILDING            = 8234,  /* building symbol                  */
    SYM_CEMETERY            = 8235,  /* cemetery symbol                  */
    SYM_CHURCH              = 8236,  /* church symbol                    */
    SYM_CIVIL               = 8237,  /* civil location symbol            */
    SYM_CROSSING            = 8238,  /* crossing symbol                  */
    SYM_HIST_TOWN           = 8239,  /* historical town symbol           */
    SYM_LEVEE               = 8240,  /* levee symbol                     */
    SYM_MILITARY            = 8241,  /* military location symbol         */
    SYM_OIL_FIELD           = 8242,  /* oil field symbol                 */
    SYM_TUNNEL              = 8243,  /* tunnel symbol                    */
    SYM_BEACH               = 8244,  /* beach symbol                     */
    SYM_FOREST              = 8245,  /* forest symbol                    */
    SYM_SUMMIT              = 8246,  /* summit symbol                    */
    SYM_LRG_RAMP_INT        = 8247,  /* large ramp intersection symbol   */
    SYM_LRG_EX_NO_SRVC      = 8248,  /* large exit without services smbl */
    SYM_BADGE               = 8249,  /* police/official badge symbol     */
    SYM_CARDS               = 8250,  /* gambling/casino symbol           */
    SYM_SNOWSKI             = 8251,  /* snow skiing symbol               */
    SYM_ICESKATE            = 8252,  /* ice skating symbol               */
    SYM_WRECKER             = 8253,  /* tow truck (wrecker) symbol       */
    SYM_BORDER              = 8254,  /* border crossing (port of entry)  */
    SYM_GEOCACHE            = 8255,  /* U geocache symbol               */
    SYM_GEOCACHE_FND        = 8256,  /* U geocache found symbol         */
    SYM_CNTCT_SMILEY        = 8257,  /* contact symbol - smiley face        */
    SYM_CNTCT_BALL_CAP      = 8258,  /* contact symbol - guy w/ ball cap    */
    SYM_CNTCT_BIG_EARS      = 8259,  /* contact symbol - guy w/ big ears    */
    SYM_CNTCT_SPIKE         = 8260,  /* contact symbol - guy w/ spike hair  */
    SYM_CNTCT_GOATEE        = 8261,  /* contact symbol - guy w/ goatee      */
    SYM_CNTCT_AFRO          = 8262,  /* contact symbol - guy w/ afro        */
    SYM_CNTCT_DREADLOCKS    = 8263,  /* contact symbol - guy w/ dreadlocks  */
    SYM_CNTCT_FEMALE1       = 8264,  /* contact symbol - general female     */
    SYM_CNTCT_FEMALE2       = 8265,  /* contact symbol - general female     */
    SYM_CNTCT_FEMALE3       = 8266,  /* contact symbol - general female     */
    SYM_CNTCT_RANGER        = 8267,  /* contact symbol - park ranger        */
    SYM_CNTCT_KUNG_FU       = 8268,  /* contact symbol - guy w/ head band   */
    SYM_CNTCT_SUMO          = 8269,  /* contact symbol - sumo wrestler      */
    SYM_CNTCT_PIRATE        = 8270,  /* contact symbol - pirate             */
    SYM_CNTCT_BIKER         = 8271,  /* contact symbol - biker              */
    SYM_CNTCT_ALIEN         = 8272,  /* contact symbol - alien              */
    SYM_CNTCT_BUG           = 8273,  /* contact symbol - bug                */
    SYM_CNTCT_CAT           = 8274,  /* contact symbol - cat                */
    SYM_CNTCT_DOG           = 8275,  /* contact symbol - dog                */
    SYM_CNTCT_PIG           = 8276,  /* contact symbol - pig                */
    SYM_CNTCT_RESERVED1     = 8277,  /* contact symbol -                    */
    SYM_CNTCT_RESERVED2     = 8278,  /* contact symbol -                    */
    SYM_CNTCT_RESERVED3     = 8279,  /* contact symbol -                    */
    SYM_CNTCT_RESERVED4     = 8280,  /* contact symbol -                    */
    SYM_CNTCT_RESERVED5     = 8281,  /* contact symbol -                    */
    SYM_HYDRANT             = 8282,  /* fire hydrant                        */
    SYM_VOICE_REC           = 8283,  /* icon for a voice recording          */
    SYM_BLUE_FLAG           = 8284,  /* blue flag                           */
    SYM_GREEN_FLAG          = 8285,  /* green flag                          */
    SYM_RED_FLAG            = 8286,  /* red flag                            */
    SYM_BLUE_PIN            = 8287,  /* blue pin                            */
    SYM_GREEN_PIN           = 8288,  /* green pin                           */
    SYM_RED_PIN             = 8289,  /* red pin                             */
    SYM_BLUE_BLOCK          = 8290,  /* blue block                          */
    SYM_GREEN_BLOCK         = 8291,  /* green block                         */
    SYM_RED_BLOCK           = 8292,  /* red block                           */
    SYM_BIKE_TRAIL          = 8293,  /* bike trail                          */
    SYM_RED_CIRCLE          = 8294,  /* red circle                          */
    SYM_GREEN_CIRCLE        = 8295,  /* green circle                        */
    SYM_BLUE_CIRCLE         = 8296,  /* blue circle                         */
    SYM_BLUE_DIAMOND        = 8299,  /* blue diamond                        */
    SYM_RED_OVAL            = 8300,  /* red oval                            */
    SYM_GREEN_OVAL          = 8301,  /* green oval                          */
    SYM_BLUE_OVAL           = 8302,  /* blue oval                           */
    SYM_RED_RECT            = 8303,  /* red rect                            */
    SYM_GREEN_RECT          = 8304,  /* green rect                          */
    SYM_BLUE_RECT           = 8305,  /* blue rect                           */
    SYM_BLUE_SQUARE         = 8308,  /* blue square                         */
    SYM_RED_A               = 8309,  /* red a                               */
    SYM_RED_B               = 8310,  /* red b                               */
    SYM_RED_C               = 8311,  /* red c                               */
    SYM_RED_D               = 8312,  /* red d                               */
    SYM_GREEN_A             = 8313,  /* green a                             */
    SYM_GREEN_B             = 8314,  /* green b                             */
    SYM_GREEN_C             = 8315,  /* green c                             */
    SYM_GREEN_D             = 8316,  /* green d                             */
    SYM_BLUE_A              = 8317,  /* blue a                              */
    SYM_BLUE_B              = 8318,  /* blue b                              */
    SYM_BLUE_C              = 8319,  /* blue c                              */
    SYM_BLUE_D              = 8320,  /* blue d                              */
    SYM_RED_0               = 8321,  /* red 0                               */
    SYM_RED_1               = 8322,  /* red 1                               */
    SYM_RED_2               = 8323,  /* red 2                               */
    SYM_RED_3               = 8324,  /* red 3                               */
    SYM_RED_4               = 8325,  /* red 4                               */
    SYM_RED_5               = 8326,  /* red 5                               */
    SYM_RED_6               = 8327,  /* red 6                               */
    SYM_RED_7               = 8328,  /* red 7                               */
    SYM_RED_8               = 8329,  /* red 8                               */
    SYM_RED_9               = 8330,  /* red 9                               */
    SYM_GREEN_0             = 8331,  /* green 0                             */
    SYM_GREEN_1             = 8332,  /* green 1                             */
    SYM_GREEN_2             = 8333,  /* green 2                             */
    SYM_GREEN_3             = 8334,  /* green 3                             */
    SYM_GREEN_4             = 8335,  /* green 4                             */
    SYM_GREEN_5             = 8336,  /* green 5                             */
    SYM_GREEN_6             = 8337,  /* green 6                             */
    SYM_GREEN_7             = 8338,  /* green 7                             */
    SYM_GREEN_8             = 8339,  /* green 8                             */
    SYM_GREEN_9             = 8340,  /* green 9                             */
    SYM_BLUE_0              = 8341,  /* blue 0                              */
    SYM_BLUE_1              = 8342,  /* blue 1                              */
    SYM_BLUE_2              = 8343,  /* blue 2                              */
    SYM_BLUE_3              = 8344,  /* blue 3                              */
    SYM_BLUE_4              = 8345,  /* blue 4                              */
    SYM_BLUE_5              = 8346,  /* blue 5                              */
    SYM_BLUE_6              = 8347,  /* blue 6                              */
    SYM_BLUE_7              = 8348,  /* blue 7                              */
    SYM_BLUE_8              = 8349,  /* blue 8                              */
    SYM_BLUE_9              = 8350,  /* blue 9                              */
    SYM_BLUE_TRIANGLE       = 8351,  /* blue triangle                       */
    SYM_GREEN_TRIANGLE      = 8352,  /* green triangle                      */
    SYM_RED_TRIANGLE        = 8353,  /* red triangle                        */
    SYM_LIBRARY             = 8354,  /* library (book)                      */
    SYM_BUS                 = 8355,  /* ground transportation               */
    SYM_CITY_HALL           = 8356,  /* city hall                           */
    SYM_WINE                = 8357,  /* winery                              */

    /*---------------------------------------------------------------
    Symbols for aviation (group 2...16383-24575...bits 15-13=010).
    ---------------------------------------------------------------*/
    SYM_AIRPORT        = 16384, /* airport symbol                   */
    SYM_INT            = 16385, /* intersection symbol              */
    SYM_NDB            = 16386, /* non-directional beacon symbol    */
    SYM_VOR            = 16387, /* VHF omni-range symbol            */
    SYM_HELIPORT       = 16388, /* heliport symbol                  */
    SYM_PRIVATE        = 16389, /* private field symbol             */
    SYM_SOFT_FLD       = 16390, /* soft field symbol                */
    SYM_TALL_TOWER     = 16391, /* tall tower symbol                */
    SYM_SHORT_TOWER    = 16392, /* short tower symbol               */
    SYM_GLIDER         = 16393, /* glider symbol                    */
    SYM_ULTRALIGHT     = 16394, /* ultralight symbol                */
    SYM_PARACHUTE      = 16395, /* parachute symbol                 */
    SYM_VORTAC         = 16396, /* VOR/TACAN SYMBOL                 */
    SYM_VORDME         = 16397, /* VOR-DME symbol                   */
    SYM_FAF            = 16398, /* first approach fix               */
    SYM_LOM            = 16399, /* localizer outer marker           */
    SYM_MAP            = 16400, /* missed approach point            */
    SYM_TACAN          = 16401, /* TACAN symbol                     */
    SYM_SEAPLANE       = 16402, /* Seaplane Base                    */

    SYM_INVALID        = 0xFFFF /* invalid symbol value (last)      */
    }   /* QueSymbolT16 */;

typedef struct
    {
    char                    id[ quePointIdLen ];    /* Point id       */
    QueSymbolT16            smbl;                   /* Point symbol   */
    QuePositionDataType     posn;                   /* Point position */
    } QuePointType;

/*----------------------------------------------------------
Address type for specifying addresses to find.
----------------------------------------------------------*/
typedef struct
    {
    const TCHAR *streetAddress;
    const TCHAR *city;
    const TCHAR *state;
    const TCHAR *country;
    const TCHAR *postalCode;
    } QueSelectAddressType;

typedef struct
    {
    TCHAR   streetAddress[QUE_ADDR_BUF_LENGTH + 1];
    TCHAR   city[QUE_ADDR_BUF_LENGTH + 1];
    TCHAR   state[QUE_ADDR_BUF_LENGTH + 1];
    TCHAR   country[QUE_ADDR_BUF_LENGTH + 1];
    TCHAR   postalCode[QUE_POST_BUF_LENGTH + 1];
    } QueAddressType;

/*----------------------------------------------------------
Que App Launch Types
Added in Que API version 1.50
----------------------------------------------------------*/
typedef uint8 QueAppT8; enum
    {
    queAppMap,
    queAppWhereTo,
    queAppGps,
    queAppTurns,
    queAppTrip,
    queAppSettings,
    queAppGpsSettings,
    queAppMarkWaypoint,

    queAppMenu,             // Launch the main page of the app.

    queAppLaunchBackground, // Launch the app in the background (no UI)
    queAppCloseBackground,  // Done with background app (called 1 time for every call to LaunchBackground)

    queAppInvalid = 255
    };

/*----------------------------------------------------------
QueRouteToVias Sort Types
Added in Que API version 1.50
----------------------------------------------------------*/
typedef uint8 QueRouteSortT8; enum
    {
    queRouteSortNone                = 0,
    queRouteSortAll                 = 1,
    queRouteSortIgnoreDest          = 3,
    queRouteSortIgnoreStart         = 5,
    queRouteSortIgnoreStartAndDest  = 7
    };

/*-----------------------------------------------------------------------------
                                   END OF FILE
-----------------------------------------------------------------------------*/

#endif  /* __QUEAPITYPES_H__ */
