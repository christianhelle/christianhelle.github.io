// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CWRAPPER_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CWRAPPER_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef CWRAPPER_EXPORTS
#define CWRAPPER_API __declspec(dllexport)
#else
#define CWRAPPER_API __declspec(dllimport)
#endif

// This class is exported from the CWrapper.dll
class CWRAPPER_API CCWrapper {
public:
	CCWrapper(void);
	// TODO: add your methods here.
};

extern CWRAPPER_API int nCWrapper;

CWRAPPER_API int fnCWrapper(void);
