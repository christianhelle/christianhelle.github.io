﻿using System;

using System.Collections.Generic;
using System.Windows.Forms;

namespace Garmin.TestApp
{
	static class Program
	{
		[MTAThread]
		static void Main()
		{
			Application.Run(new Form1());
		}
	}
}