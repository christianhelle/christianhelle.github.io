﻿namespace Garmin.TestApp
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.MainMenu mainMenu;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.btnOpenNavigator = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.tbStreet = new System.Windows.Forms.TextBox();
			this.tbZipCode = new System.Windows.Forms.TextBox();
			this.tbCity = new System.Windows.Forms.TextBox();
			this.tbCountry = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.btnNavigateToPos = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.tbLongitude = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.tbLatitude = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.Add(this.menuItem1);
			// 
			// menuItem1
			// 
			this.menuItem1.Text = "Exit";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// btnOpenNavigator
			// 
			this.btnOpenNavigator.Location = new System.Drawing.Point(10, 177);
			this.btnOpenNavigator.Name = "btnOpenNavigator";
			this.btnOpenNavigator.Size = new System.Drawing.Size(220, 24);
			this.btnOpenNavigator.TabIndex = 0;
			this.btnOpenNavigator.Text = "Launch Garmin";
			this.btnOpenNavigator.Click += new System.EventHandler(this.OpenNavigator_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(123, 207);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(107, 24);
			this.button1.TabIndex = 1;
			this.button1.Text = "Show on Map";
			this.button1.Click += new System.EventHandler(this.ShowOnMap_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(10, 207);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(107, 24);
			this.button2.TabIndex = 2;
			this.button2.Text = "Navigate To";
			this.button2.Click += new System.EventHandler(this.NavigateTo_Click);
			// 
			// tbStreet
			// 
			this.tbStreet.Location = new System.Drawing.Point(75, 3);
			this.tbStreet.Name = "tbStreet";
			this.tbStreet.Size = new System.Drawing.Size(150, 21);
			this.tbStreet.TabIndex = 3;
			this.tbStreet.Text = "Hørkær 24";
			// 
			// tbZipCode
			// 
			this.tbZipCode.Location = new System.Drawing.Point(75, 30);
			this.tbZipCode.Name = "tbZipCode";
			this.tbZipCode.Size = new System.Drawing.Size(150, 21);
			this.tbZipCode.TabIndex = 4;
			this.tbZipCode.Text = "2730";
			// 
			// tbCity
			// 
			this.tbCity.Location = new System.Drawing.Point(75, 57);
			this.tbCity.Name = "tbCity";
			this.tbCity.Size = new System.Drawing.Size(150, 21);
			this.tbCity.TabIndex = 5;
			this.tbCity.Text = "Herlev";
			// 
			// tbCountry
			// 
			this.tbCountry.Location = new System.Drawing.Point(75, 84);
			this.tbCountry.Name = "tbCountry";
			this.tbCountry.Size = new System.Drawing.Size(150, 21);
			this.tbCountry.TabIndex = 6;
			this.tbCountry.Text = "Denmark";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(3, 3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(66, 20);
			this.label1.Text = "Street";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(3, 30);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(66, 20);
			this.label2.Text = "Zip Code";
			this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(3, 58);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(66, 20);
			this.label3.Text = "City";
			this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(3, 84);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(66, 20);
			this.label4.Text = "Country";
			this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// btnNavigateToPos
			// 
			this.btnNavigateToPos.Location = new System.Drawing.Point(10, 238);
			this.btnNavigateToPos.Name = "btnNavigateToPos";
			this.btnNavigateToPos.Size = new System.Drawing.Size(220, 24);
			this.btnNavigateToPos.TabIndex = 7;
			this.btnNavigateToPos.Text = "Navigate To Coordinates";
			this.btnNavigateToPos.Click += new System.EventHandler(this.NavigateToPos_Click);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(3, 111);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(66, 20);
			this.label5.Text = "Longitude";
			this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// tbLongitude
			// 
			this.tbLongitude.Location = new System.Drawing.Point(75, 111);
			this.tbLongitude.Name = "tbLongitude";
			this.tbLongitude.Size = new System.Drawing.Size(150, 21);
			this.tbLongitude.TabIndex = 9;
			this.tbLongitude.Text = "12.437316";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(3, 138);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(66, 20);
			this.label6.Text = "Latitude";
			this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// tbLatitude
			// 
			this.tbLatitude.Location = new System.Drawing.Point(75, 138);
			this.tbLatitude.Name = "tbLatitude";
			this.tbLatitude.Size = new System.Drawing.Size(150, 21);
			this.tbLatitude.TabIndex = 12;
			this.tbLatitude.Text = "55.717972";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(240, 268);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.tbLatitude);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.tbLongitude);
			this.Controls.Add(this.btnNavigateToPos);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.tbCountry);
			this.Controls.Add(this.tbCity);
			this.Controls.Add(this.tbZipCode);
			this.Controls.Add(this.tbStreet);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnOpenNavigator);
			this.Menu = this.mainMenu;
			this.Name = "Form1";
			this.Text = "Garmin Test App";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.Button btnOpenNavigator;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TextBox tbStreet;
		private System.Windows.Forms.TextBox tbZipCode;
		private System.Windows.Forms.TextBox tbCity;
		private System.Windows.Forms.TextBox tbCountry;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnNavigateToPos;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox tbLongitude;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox tbLatitude;
	}
}

