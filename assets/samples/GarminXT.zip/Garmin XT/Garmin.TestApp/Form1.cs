﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Garmin.NETCF;
using System.Diagnostics;
using System.Globalization;

namespace Garmin.TestApp
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void menuItem1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void OpenNavigator_Click(object sender, EventArgs e)
		{
			try {
				GarminXT xt = new GarminXT();
				xt.OpenNavigator();
			}
			catch (GarminNativeException ex) {
				Debug.Assert(false, ex.Message, ex.StackTrace);
			}
		}

		private void NavigateTo_Click(object sender, EventArgs e)
		{
			try {
				GarminXT xt = new GarminXT();
				xt.NavigateToAddress(
					tbStreet.Text,
					tbCity.Text,
					tbZipCode.Text,
					null,
					tbCountry.Text);
			}
			catch (GarminNativeException ex) {
				Debug.Assert(false, ex.Message, ex.StackTrace);
			}
		}

		private void ShowOnMap_Click(object sender, EventArgs e)
		{
			try {
				GarminXT xt = new GarminXT();
				xt.ShowAddressOnMap(
					tbStreet.Text,
					tbCity.Text,
					tbZipCode.Text,
					null,
					tbCountry.Text);
			}
			catch (GarminNativeException ex) {
				Debug.Assert(false, ex.Message, ex.StackTrace);
			}
		}

		private void NavigateToPos_Click(object sender, EventArgs e)
		{
			try {
				GarminXT xt = new GarminXT();
				xt.NavigateToCoordinates(
					Convert.ToDouble(tbLatitude.Text),
					Convert.ToDouble(tbLongitude.Text));
			}
			catch (GarminNativeException ex) {
				Debug.Assert(false, ex.Message, ex.StackTrace);
			}
		}
	}
}